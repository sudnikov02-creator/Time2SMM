import { corsHeaders } from "@supabase/supabase-js/cors";

const MAX_LEN = 500;
const sanitize = (v: unknown, max = MAX_LEN): string => {
  if (typeof v !== "string") return "";
  // Strip control chars and trim; cap length to prevent prompt-injection abuse.
  return v.replace(/[\u0000-\u001F\u007F]/g, " ").trim().slice(0, max);
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const body = await req.json().catch(() => null);
    if (!body || typeof body !== "object") {
      return new Response(JSON.stringify({ error: "Некорректный запрос" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const title = sanitize((body as Record<string, unknown>).title, 300);
    const source = sanitize((body as Record<string, unknown>).source, 50);
    const postType = sanitize((body as Record<string, unknown>).postType, 50);
    const projectName = sanitize((body as Record<string, unknown>).projectName, 100);

    if (!title) {
      return new Response(JSON.stringify({ error: "title is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      console.error("LOVABLE_API_KEY missing");
      return new Response(JSON.stringify({ error: "Сервис временно недоступен" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const system = `Ты — опытный SMM-копирайтер. Пишешь живые, цепляющие посты на русском языке.
Учитывай платформу и формат публикации. Используй короткие абзацы, 1–3 уместных эмодзи (не больше),
конкретику вместо общих слов, мягкий призыв к действию в конце. Без воды и канцеляризмов.`;

    const user = `Заголовок: ${title}
Площадка: ${source || "—"}
Формат: ${postType || "—"}
Проект: ${projectName || "—"}

Напиши готовый текст поста на основе заголовка. Только сам текст поста, без пояснений и заголовка.`;

    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: system },
          { role: "user", content: user },
        ],
      }),
    });

    if (resp.status === 429) {
      return new Response(JSON.stringify({ error: "Превышен лимит. Попробуйте позже." }), {
        status: 429,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (resp.status === 402) {
      return new Response(
        JSON.stringify({ error: "Закончились кредиты Lovable AI. Пополните рабочее пространство." }),
        { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    if (!resp.ok) {
      const t = await resp.text().catch(() => "");
      console.error("AI gateway error", resp.status, t);
      return new Response(JSON.stringify({ error: "Не удалось сгенерировать пост. Попробуйте ещё раз." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await resp.json();
    const content: string = data?.choices?.[0]?.message?.content ?? "";

    return new Response(JSON.stringify({ content }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("generate-post error", e);
    return new Response(JSON.stringify({ error: "Внутренняя ошибка. Попробуйте позже." }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});