
-- USERS
CREATE TABLE public.app_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name TEXT NOT NULL,
  password TEXT NOT NULL DEFAULT '1111',
  role TEXT NOT NULL DEFAULT 'user',
  avatar_color TEXT NOT NULL DEFAULT '#6366f1',
  blocked_until TIMESTAMPTZ,
  fired_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- PROJECTS
CREATE TABLE public.projects (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  color TEXT NOT NULL DEFAULT '#6366f1',
  owner_id UUID REFERENCES public.app_users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- POSTS
CREATE TABLE public.posts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL DEFAULT '',
  scheduled_date DATE NOT NULL,
  scheduled_time TIME,
  source TEXT NOT NULL DEFAULT 'Telegram',
  post_type TEXT NOT NULL DEFAULT 'Пост',
  project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
  author_id UUID REFERENCES public.app_users(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- POST IMAGES
CREATE TABLE public.post_images (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  storage_path TEXT NOT NULL,
  public_url TEXT NOT NULL,
  position INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- SETTINGS LISTS (sources / post_types)
CREATE TABLE public.app_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category TEXT NOT NULL, -- 'source' | 'post_type'
  value TEXT NOT NULL,
  position INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ENABLE RLS
ALTER TABLE public.app_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.post_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- POLICIES: open access (internal team tool with custom auth)
CREATE POLICY "anyone_select_app_users" ON public.app_users FOR SELECT USING (true);
CREATE POLICY "anyone_modify_app_users" ON public.app_users FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "anyone_select_projects" ON public.projects FOR SELECT USING (true);
CREATE POLICY "anyone_modify_projects" ON public.projects FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "anyone_select_posts" ON public.posts FOR SELECT USING (true);
CREATE POLICY "anyone_modify_posts" ON public.posts FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "anyone_select_post_images" ON public.post_images FOR SELECT USING (true);
CREATE POLICY "anyone_modify_post_images" ON public.post_images FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "anyone_select_app_settings" ON public.app_settings FOR SELECT USING (true);
CREATE POLICY "anyone_modify_app_settings" ON public.app_settings FOR ALL USING (true) WITH CHECK (true);

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.tg_set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_app_users_updated BEFORE UPDATE ON public.app_users FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();
CREATE TRIGGER trg_projects_updated BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();
CREATE TRIGGER trg_posts_updated BEFORE UPDATE ON public.posts FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- Indexes
CREATE INDEX idx_posts_date ON public.posts(scheduled_date);
CREATE INDEX idx_posts_project ON public.posts(project_id);
CREATE INDEX idx_post_images_post ON public.post_images(post_id);

-- Seed: admin + default settings
INSERT INTO public.app_users (full_name, password, role, avatar_color)
VALUES ('Администратор', '1111', 'admin', '#6366f1');

INSERT INTO public.app_settings (category, value, position) VALUES
('source', 'Telegram', 1),
('source', 'Instagram', 2),
('source', 'VK', 3),
('source', 'TikTok', 4),
('source', 'YouTube', 5),
('source', 'Facebook', 6),
('source', 'X / Twitter', 7),
('source', 'Threads', 8),
('post_type', 'Пост', 1),
('post_type', 'Stories', 2),
('post_type', 'Reels', 3),
('post_type', 'Shorts', 4),
('post_type', 'Видео', 5),
('post_type', 'Карусель', 6),
('post_type', 'Опрос', 7);

-- Storage bucket for post images (public)
INSERT INTO storage.buckets (id, name, public)
VALUES ('post-images', 'post-images', true);

CREATE POLICY "post_images_public_read" ON storage.objects
FOR SELECT USING (bucket_id = 'post-images');

CREATE POLICY "post_images_public_write" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'post-images');

CREATE POLICY "post_images_public_update" ON storage.objects
FOR UPDATE USING (bucket_id = 'post-images');

CREATE POLICY "post_images_public_delete" ON storage.objects
FOR DELETE USING (bucket_id = 'post-images');
