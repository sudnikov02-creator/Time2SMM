import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth";
import { SplashScreen } from "@/components/SplashScreen";
import { WelcomeSplash } from "@/components/WelcomeSplash";
import { FarewellSplash } from "@/components/FarewellSplash";
import { LoginScreen } from "@/components/LoginScreen";
import { AppHeader, type CalendarView } from "@/components/AppHeader";
import { RightSidebar } from "@/components/RightSidebar";
import { CalendarSurface } from "@/components/calendar/CalendarView";
import { PostEditorPanel } from "@/components/PostEditorPanel";
import { SettingsOverlay } from "@/components/SettingsOverlay";
import { FullscreenDayView } from "@/components/FullscreenDayView";
import { usePosts, useProjects, useSettings } from "@/lib/data";
import { formatYMD } from "@/lib/dateUtils";
import type { Post, Project } from "@/lib/types";
import { cn } from "@/lib/utils";
import { toast } from "@/components/ui/cinema-toast";
import { FullscreenConfirm } from "@/components/ui/fullscreen-confirm";

const Index = () => {
  const { user } = useAuth();
  const [splashDone, setSplashDone] = useState(false);
  const [workspaceReady, setWorkspaceReady] = useState(false);

  // Загрузка приложения 6-10 сек
  if (!splashDone) {
    return <SplashScreen label="Загружаем сервис" onDone={() => setSplashDone(true)} />;
  }

  if (!user) return <LoginScreen />;

  // После входа: персональное приветствие 5 сек
  if (!workspaceReady) {
    return <WelcomeSplash name={user.full_name} duration={5000} onDone={() => setWorkspaceReady(true)} />;
  }

  return <Workspace />;
};

function Workspace() {
  const { user, logout } = useAuth();
  const [view, setView] = useState<CalendarView>("month");
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [farewellOpen, setFarewellOpen] = useState(false);
  const [confirmLogout, setConfirmLogout] = useState(false);

  const [dayDate, setDayDate] = useState<Date | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editorPost, setEditorPost] = useState<Post | null>(null);

  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState<"profile" | "password" | "catalogs" | "appearance" | "users">("profile");

  const { data: posts = [] } = usePosts();
  const { data: projects = [] } = useProjects();
  const { data: settings = [] } = useSettings();

  const projectsMap = useMemo(() => {
    const m = new Map<string, Project>();
    for (const p of projects) m.set(p.id, p);
    return m;
  }, [projects]);

  const selectedProject = selectedProjectId ? projectsMap.get(selectedProjectId) ?? null : null;

  const filteredForList = useMemo(() => {
    if (!dayDate) return [];
    const ymd = formatYMD(dayDate);
    return posts
      .filter((p) => p.scheduled_date === ymd)
      .filter((p) => !selectedProjectId || p.project_id === selectedProjectId)
      .sort((a, b) => (a.scheduled_time ?? "").localeCompare(b.scheduled_time ?? ""));
  }, [posts, dayDate, selectedProjectId]);

  function openDay(d: Date) {
    setDayDate(d);
    setEditorOpen(false);
    setEditorPost(null);
  }
  function openAddOnDate(d: Date) {
    if (!selectedProjectId) {
      toast.warning("Выберите проект", {
        description: "В режиме «Все проекты» новый пост создать нельзя — сначала выберите проект справа.",
      });
      return;
    }
    setDayDate(d);
    setEditorPost(null);
    setEditorOpen(true);
  }
  function openPost(p: Post) {
    setDayDate(new Date(p.scheduled_date + "T00:00:00"));
    setEditorPost(p);
    setEditorOpen(true);
  }
  function closeDay() {
    setEditorOpen(false);
    setEditorPost(null);
    setDayDate(null);
  }

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        if (editorOpen) {
          setEditorOpen(false);
          setEditorPost(null);
        } else if (dayDate) {
          setDayDate(null);
        }
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [editorOpen, dayDate]);

  const dayMode = !!dayDate;

  return (
    <div className="flex h-screen flex-col overflow-hidden">
      {farewellOpen && user && (
        <FarewellSplash
          name={user.full_name}
          onDone={() => {
            setFarewellOpen(false);
            logout();
          }}
        />
      )}

      <FullscreenConfirm
        open={confirmLogout}
        onClose={() => setConfirmLogout(false)}
        title="Выйти из системы?"
        description="Текущая сессия будет завершена. Все несохранённые черновики постов могут пропасть."
        confirmLabel="Выйти"
        cancelLabel="Остаться"
        tone="warning"
        onConfirm={() => {
          setConfirmLogout(false);
          setFarewellOpen(true);
        }}
      />
      {/* Header — hidden in fullscreen day mode */}
      <div
        className={cn(
          "transition-[max-height,opacity] duration-500 ease-soft overflow-hidden",
          dayMode ? "max-h-0 opacity-0" : "max-h-32 opacity-100",
        )}
      >
        <AppHeader
          view={view}
          setView={setView}
          currentDate={currentDate}
          setCurrentDate={setCurrentDate}
          goToday={() => setCurrentDate(new Date())}
        />
      </div>

      <div className="flex min-h-0 flex-1 overflow-hidden">
        <main className="min-h-0 min-w-0 flex-1 overflow-hidden">
          {dayMode && dayDate ? (
            <div key={formatYMD(dayDate)} className="h-full p-3 md:p-4">
              <FullscreenDayView
                date={dayDate}
                posts={filteredForList}
                projectsMap={projectsMap}
                selectedProject={selectedProject}
                onClose={closeDay}
                onAdd={() => {
                  setEditorPost(null);
                  setEditorOpen(true);
                }}
                onPick={(p) => {
                  setEditorPost(p);
                  setEditorOpen(true);
                }}
                selectedPostId={editorPost?.id ?? null}
                rightSlot={
                  editorOpen ? (
                    <PostEditorPanel
                      embedded
                      open={editorOpen}
                      onClose={() => {
                        setEditorOpen(false);
                        setEditorPost(null);
                      }}
                      date={dayDate}
                      post={editorPost}
                      projects={projects}
                      settings={settings}
                      authorId={user?.id ?? null}
                    />
                  ) : undefined
                }
              />
            </div>
          ) : (
            <div className={cn("h-full", view === "month" ? "" : "")}>
              <CalendarSurface
                view={view}
                currentDate={currentDate}
                posts={posts}
                projects={projects}
                selectedProjectId={selectedProjectId}
                onPickDate={openDay}
                onAddOnDate={openAddOnDate}
                onPickPost={openPost}
              />
            </div>
          )}
        </main>
        <RightSidebar
          selectedProjectId={selectedProjectId}
          setSelectedProjectId={setSelectedProjectId}
          onOpenSettings={() => {
            setSettingsTab("profile");
            setSettingsOpen(true);
          }}
          onOpenAdmin={() => {
            setSettingsTab("users");
            setSettingsOpen(true);
          }}
          onLogout={() => setConfirmLogout(true)}
        />
      </div>

      <SettingsOverlay
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        initialTab={settingsTab}
      />
    </div>
  );
}

export default Index;
