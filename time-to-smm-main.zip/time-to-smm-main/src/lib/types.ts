export interface Project {
  id: string;
  name: string;
  color: string;
  owner_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Post {
  id: string;
  title: string;
  content: string;
  scheduled_date: string; // YYYY-MM-DD
  scheduled_time: string | null;
  source: string;
  post_type: string;
  project_id: string | null;
  author_id: string | null;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface PostImage {
  id: string;
  post_id: string;
  storage_path: string;
  public_url: string;
  position: number;
  created_at: string;
}

export interface AppSetting {
  id: string;
  category: "source" | "post_type";
  value: string;
  position: number;
  created_at: string;
}