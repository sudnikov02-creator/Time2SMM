import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Project, Post, PostImage, AppSetting } from "./types";
import type { AppUser } from "./auth";

/* ---------------- PROJECTS ---------------- */
export function useProjects() {
  return useQuery({
    queryKey: ["projects"],
    queryFn: async (): Promise<Project[]> => {
      const { data, error } = await supabase
        .from("projects")
        .select("*")
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Project[];
    },
  });
}

export function useProjectMutations() {
  const qc = useQueryClient();
  const create = useMutation({
    mutationFn: async (input: { name: string; color: string; owner_id?: string | null }) => {
      const { data, error } = await supabase.from("projects").insert(input).select().single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["projects"] }),
  });
  const update = useMutation({
    mutationFn: async (input: { id: string } & Partial<Project>) => {
      const { id, ...rest } = input;
      const { error } = await supabase.from("projects").update(rest).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["projects"] }),
  });
  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("projects").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["projects"] });
      qc.invalidateQueries({ queryKey: ["posts"] });
    },
  });
  return { create, update, remove };
}

/* ---------------- POSTS ---------------- */
export function usePosts() {
  return useQuery({
    queryKey: ["posts"],
    queryFn: async (): Promise<Post[]> => {
      const { data, error } = await supabase
        .from("posts")
        .select("*")
        .order("scheduled_date", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Post[];
    },
  });
}

export function usePostMutations() {
  const qc = useQueryClient();
  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["posts"] });
  };
  const create = useMutation({
    mutationFn: async (input: Partial<Post>) => {
      const { data, error } = await supabase.from("posts").insert(input as any).select().single();
      if (error) throw error;
      return data as Post;
    },
    onSuccess: invalidate,
  });
  const update = useMutation({
    mutationFn: async (input: { id: string } & Partial<Post>) => {
      const { id, ...rest } = input;
      const { error } = await supabase.from("posts").update(rest as any).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("posts").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  return { create, update, remove };
}

/* ---------------- POST IMAGES ---------------- */
export function usePostImages(postId: string | null) {
  return useQuery({
    queryKey: ["post-images", postId],
    enabled: !!postId,
    queryFn: async (): Promise<PostImage[]> => {
      const { data, error } = await supabase
        .from("post_images")
        .select("*")
        .eq("post_id", postId!)
        .order("position", { ascending: true });
      if (error) throw error;
      return (data ?? []) as PostImage[];
    },
  });
}

export function usePostImageMutations(postId: string | null) {
  const qc = useQueryClient();
  const upload = useMutation({
    mutationFn: async (file: File) => {
      if (!postId) throw new Error("postId required");
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${postId}/${crypto.randomUUID()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("post-images").upload(path, file, {
        cacheControl: "3600",
        upsert: false,
      });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("post-images").getPublicUrl(path);
      const { error: insErr } = await supabase.from("post_images").insert({
        post_id: postId,
        storage_path: path,
        public_url: pub.publicUrl,
      });
      if (insErr) throw insErr;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["post-images", postId] }),
  });
  const remove = useMutation({
    mutationFn: async (img: PostImage) => {
      await supabase.storage.from("post-images").remove([img.storage_path]);
      const { error } = await supabase.from("post_images").delete().eq("id", img.id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["post-images", postId] }),
  });
  return { upload, remove };
}

/* ---------------- USERS ---------------- */
export function useUsers() {
  return useQuery({
    queryKey: ["users"],
    queryFn: async (): Promise<AppUser[]> => {
      const { data, error } = await supabase
        .from("app_users")
        .select("*")
        .order("role", { ascending: true })
        .order("full_name", { ascending: true });
      if (error) throw error;
      return (data ?? []) as AppUser[];
    },
  });
}

export function useUserMutations() {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["users"] });
  const create = useMutation({
    mutationFn: async (input: Partial<AppUser>) => {
      const { data, error } = await supabase.from("app_users").insert(input as any).select().single();
      if (error) throw error;
      return data as AppUser;
    },
    onSuccess: invalidate,
  });
  const update = useMutation({
    mutationFn: async (input: { id: string } & Partial<AppUser>) => {
      const { id, ...rest } = input;
      const { error } = await supabase.from("app_users").update(rest as any).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("app_users").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  return { create, update, remove };
}

/* ---------------- SETTINGS ---------------- */
export function useSettings() {
  return useQuery({
    queryKey: ["settings"],
    queryFn: async (): Promise<AppSetting[]> => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("*")
        .order("category", { ascending: true })
        .order("position", { ascending: true });
      if (error) throw error;
      return (data ?? []) as AppSetting[];
    },
  });
}

export function useSettingMutations() {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["settings"] });
  const create = useMutation({
    mutationFn: async (input: { category: "source" | "post_type"; value: string; position?: number }) => {
      const { data, error } = await supabase.from("app_settings").insert(input).select().single();
      if (error) throw error;
      return data;
    },
    onSuccess: invalidate,
  });
  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("app_settings").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });
  return { create, remove };
}