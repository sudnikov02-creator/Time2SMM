import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface AppUser {
  id: string;
  full_name: string;
  password: string;
  role: "admin" | "user";
  avatar_color: string;
  blocked_until: string | null;
  fired_at: string | null;
  created_at: string;
  updated_at: string;
}

interface AuthCtx {
  user: AppUser | null;
  setUser: (u: AppUser | null) => void;
  refresh: () => Promise<void>;
  logout: () => void;
}

const Ctx = createContext<AuthCtx | null>(null);
const KEY = "tts-current-user-id";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUserState] = useState<AppUser | null>(null);

  const refresh = useCallback(async () => {
    const id = localStorage.getItem(KEY);
    if (!id) {
      setUserState(null);
      return;
    }
    const { data } = await supabase.from("app_users").select("*").eq("id", id).maybeSingle();
    if (data) setUserState(data as AppUser);
    else {
      localStorage.removeItem(KEY);
      setUserState(null);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const setUser = (u: AppUser | null) => {
    if (u) localStorage.setItem(KEY, u.id);
    else localStorage.removeItem(KEY);
    setUserState(u);
  };

  const logout = () => setUser(null);

  return <Ctx.Provider value={{ user, setUser, refresh, logout }}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}