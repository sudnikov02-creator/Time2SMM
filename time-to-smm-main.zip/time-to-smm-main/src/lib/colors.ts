// 20 пастельных цветов для проектов
export const PROJECT_COLORS = [
  "#FFB5BA", // soft rose
  "#FFC9A8", // peach
  "#FFD8A8", // apricot
  "#FFE5A8", // butter
  "#FFF1B5", // vanilla
  "#E2F0B5", // pistachio
  "#C9E8B6", // mint
  "#B5E2C5", // sea-foam
  "#B5E0DA", // aqua mist
  "#B5D8E8", // baby blue
  "#B5C7E8", // periwinkle
  "#C9B5E8", // lavender
  "#D8B5E8", // wisteria
  "#E8B5DA", // rose petal
  "#F5C2D6", // bubblegum
  "#F0D6C2", // sand
  "#E0D2C2", // latte
  "#D6E0DA", // sage
  "#D8D2E8", // lilac fog
  "#E2C9D2", // dusty pink
] as const;

// Brighter palette for avatars (still soft, but readable on white text)
export const AVATAR_COLORS = [
  "#F472B6", "#FB7185", "#F87171", "#FB923C", "#FBBF24",
  "#A3E635", "#4ADE80", "#34D399", "#22D3EE", "#60A5FA",
  "#818CF8", "#A78BFA", "#C084FC", "#E879F9", "#F0ABFC",
  "#94A3B8", "#A8A29E", "#84CC16", "#06B6D4", "#EC4899",
] as const;

export function readableTextColor(hex: string): "#fff" | "#0f172a" {
  const c = hex.replace("#", "");
  const r = parseInt(c.slice(0, 2), 16);
  const g = parseInt(c.slice(2, 4), 16);
  const b = parseInt(c.slice(4, 6), 16);
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return lum > 0.62 ? "#0f172a" : "#fff";
}

export function withAlpha(hex: string, alpha: number) {
  const c = hex.replace("#", "");
  const r = parseInt(c.slice(0, 2), 16);
  const g = parseInt(c.slice(2, 4), 16);
  const b = parseInt(c.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}