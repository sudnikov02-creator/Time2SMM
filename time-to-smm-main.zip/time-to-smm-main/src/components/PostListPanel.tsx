import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { formatLongWeekday, isSameDay } from "@/lib/dateUtils";
import { Plus, X, Clock } from "lucide-react";
import type { Post, Project } from "@/lib/types";

interface Props {
  open: boolean;
  date: Date | null;
  posts: Post[];
  projectsMap: Map<string, Project>;
  onClose: () => void;
  onAdd: () => void;
  onPick: (p: Post) => void;
  selectedPostId: string | null;
}

export function PostListPanel({ open, date, posts, projectsMap, onClose, onAdd, onPick, selectedPostId }: Props) {
  const isToday = date ? isSameDay(date, new Date()) : false;
  const list = date ? posts : [];
  return (
    <aside
      className={cn(
        "pointer-events-none fixed inset-y-0 right-0 z-40 flex w-[380px] max-w-full flex-col border-l border-border bg-card/95 backdrop-blur-xl shadow-elevated",
        "transition-[transform,opacity] duration-[600ms] ease-soft lg:right-72",
        open ? "translate-x-0 opacity-100 pointer-events-auto" : "translate-x-[110%] opacity-0",
      )}
    >
      <div className="flex items-start justify-between border-b border-border px-5 py-4">
        <div>
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
            {isToday ? "Сегодня" : "Запланировано на"}
          </div>
          <h3 className="mt-0.5 font-display text-lg font-semibold capitalize">
            {date ? formatLongWeekday(date) : ""}
          </h3>
        </div>
        <Button variant="ghost" size="icon-sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto scroll-thin px-3 py-3">
        {list.length === 0 && (
          <div className="grid h-full place-items-center px-6 text-center">
            <div>
              <div className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-accent">
                <Clock className="h-6 w-6 text-accent-foreground" />
              </div>
              <h4 className="font-display text-base font-semibold">Постов на этот день нет</h4>
              <p className="mt-1 text-xs text-muted-foreground">
                Добавьте первый — справа откроется редактор.
              </p>
            </div>
          </div>
        )}
        <div className="space-y-2">
          {list.map((p, i) => {
            const proj = p.project_id ? projectsMap.get(p.project_id) : null;
            const color = proj?.color ?? "#94a3b8";
            const active = selectedPostId === p.id;
            return (
              <button
                key={p.id}
                onClick={() => onPick(p)}
                className={cn(
                  "group flex w-full items-start gap-3 rounded-2xl border p-3 text-left transition-all duration-300",
                  "hover:-translate-y-0.5 hover:shadow-soft",
                  active ? "border-primary/40 bg-accent/40 shadow-soft" : "border-border bg-background/60",
                )}
                style={{ animation: `fade-in 350ms ${i * 50}ms both` }}
              >
                <div
                  className="grid h-11 w-14 shrink-0 place-items-center rounded-xl text-xs font-semibold"
                  style={{ background: `${color}18`, color }}
                >
                  {p.scheduled_time?.slice(0, 5) ?? "—"}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate font-medium">{p.title}</div>
                  <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                    <span>{p.source}</span>
                    <span className="opacity-50">•</span>
                    <span>{p.post_type}</span>
                    {proj && (
                      <>
                        <span className="opacity-50">•</span>
                        <span style={{ color }}>{proj.name}</span>
                      </>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="border-t border-border p-4">
        <Button onClick={onAdd} size="lg" className="w-full">
          <Plus className="h-4 w-4" /> Добавить пост
        </Button>
      </div>
    </aside>
  );
}