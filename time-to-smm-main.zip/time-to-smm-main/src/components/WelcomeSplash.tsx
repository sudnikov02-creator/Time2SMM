import { useEffect, useState } from "react";
import { BrandLogo } from "./BrandLogo";

interface Props {
  name: string;
  duration?: number;
  onDone: () => void;
}

function greeting() {
  const h = new Date().getHours();
  if (h < 5) return "Доброй ночи";
  if (h < 12) return "Доброе утро";
  if (h < 18) return "Добрый день";
  return "Добрый вечер";
}

export function WelcomeSplash({ name, duration = 5000, onDone }: Props) {
  const [progress, setProgress] = useState(2);

  useEffect(() => {
    const start = performance.now();
    let raf = 0;
    const tick = () => {
      const elapsed = performance.now() - start;
      const pct = Math.min(99, (elapsed / duration) * 100);
      setProgress(pct);
      if (elapsed >= duration) {
        setProgress(100);
        setTimeout(onDone, 350);
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [duration, onDone]);

  // Per-letter animation
  const letters = name.split("");

  return (
    <div className="fixed inset-0 z-50 grid place-items-center overflow-hidden bg-background">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(900px_circle_at_50%_20%,hsl(var(--primary)/0.10),transparent_60%)]" />

      <div className="relative z-10 flex w-[min(960px,92vw)] flex-col items-center gap-14 text-center">
        <div className="animate-fade-in">
          <BrandLogo size={28} />
        </div>

        <div className="space-y-6">
          <p
            className="font-display text-[11px] font-medium uppercase tracking-[0.4em] text-muted-foreground animate-fade-in"
            style={{ animationDelay: "80ms" }}
          >
            {greeting()},
          </p>
          <h1
            className="font-display font-extralight lowercase tracking-[-0.04em] text-foreground"
            style={{ fontSize: "clamp(3.5rem, 11vw, 10rem)", lineHeight: 0.95 }}
          >
            <span aria-label={name} className="inline-flex flex-wrap justify-center">
              {letters.map((ch, i) => (
                <span
                  key={i}
                  className="inline-block animate-letter-rise"
                  style={{ animationDelay: `${250 + i * 50}ms`, whiteSpace: "pre" }}
                >
                  {ch}
                </span>
              ))}
            </span>
            <span
              className="inline-block animate-letter-rise bg-gradient-brand bg-clip-text text-transparent"
              style={{ animationDelay: `${250 + letters.length * 50 + 100}ms` }}
            >
              .
            </span>
          </h1>
        </div>

        <div
          className="w-full max-w-md animate-fade-in"
          style={{ animationDelay: `${500 + letters.length * 50}ms` }}
        >
          <div className="relative h-px w-full overflow-hidden bg-border/60">
            <div
              className="absolute inset-y-0 left-0 bg-gradient-brand transition-[width] duration-300 ease-soft"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="mt-4 flex justify-between text-[10px] font-medium uppercase tracking-[0.3em] text-muted-foreground">
            <span>Открываем рабочее пространство</span>
            <span className="tabular-nums">{Math.floor(progress)}%</span>
          </div>
        </div>
      </div>
    </div>
  );
}