import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, CalendarDays } from "lucide-react";
import { BrandLogo } from "./BrandLogo";
import { addMonths, addDays, RU_MONTHS, formatLongWeekday } from "@/lib/dateUtils";
import { cn } from "@/lib/utils";

export type CalendarView = "month" | "week" | "day";

interface Props {
  view: CalendarView;
  setView: (v: CalendarView) => void;
  currentDate: Date;
  setCurrentDate: (d: Date) => void;
  goToday: () => void;
}

export function AppHeader({ view, setView, currentDate, setCurrentDate, goToday }: Props) {
  const step = view === "month" ? "month" : view === "week" ? "week" : "day";

  function nav(dir: -1 | 1) {
    if (step === "month") setCurrentDate(addMonths(currentDate, dir));
    else if (step === "week") setCurrentDate(addDays(currentDate, dir * 7));
    else setCurrentDate(addDays(currentDate, dir));
  }

  const title =
    view === "day"
      ? formatLongWeekday(currentDate)
      : `${RU_MONTHS[currentDate.getMonth()]} ${currentDate.getFullYear()}`;

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/70 backdrop-blur-xl">
      <div className="flex h-16 items-center gap-4 px-5">
        <BrandLogo />

        <div className="ml-2 hidden items-center gap-1 md:flex">
          <Button variant="ghost" size="icon" onClick={() => nav(-1)} aria-label="Назад">
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <div className="min-w-[200px] px-2 text-center font-display text-lg font-semibold capitalize tracking-tight">
            {title}
          </div>
          <Button variant="ghost" size="icon" onClick={() => nav(1)} aria-label="Вперёд">
            <ChevronRight className="h-5 w-5" />
          </Button>
          <Button variant="soft" size="pill" onClick={goToday} className="ml-2">
            <CalendarDays className="h-3.5 w-3.5" /> Сегодня
          </Button>
        </div>

        <div className="ml-auto">
          <ViewSwitch view={view} setView={setView} />
        </div>
      </div>

      {/* mobile sub-row */}
      <div className="flex items-center justify-between gap-2 border-t border-border px-4 py-2 md:hidden">
        <Button variant="ghost" size="icon-sm" onClick={() => nav(-1)}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="font-display text-sm font-semibold capitalize">{title}</div>
        <div className="flex gap-1">
          <Button variant="soft" size="pill" onClick={goToday}>Сегодня</Button>
          <Button variant="ghost" size="icon-sm" onClick={() => nav(1)}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}

function ViewSwitch({ view, setView }: { view: CalendarView; setView: (v: CalendarView) => void }) {
  const items: { value: CalendarView; label: string }[] = [
    { value: "month", label: "Месяц" },
    { value: "week", label: "Неделя" },
    { value: "day", label: "День" },
  ];
  return (
    <div className="relative inline-flex rounded-full border border-border bg-card/70 p-1 backdrop-blur">
      {items.map((it) => {
        const active = view === it.value;
        return (
          <button
            key={it.value}
            onClick={() => setView(it.value)}
            className={cn(
              "relative z-10 rounded-full px-4 py-1.5 text-xs font-medium transition-all duration-300 ease-soft",
              active ? "text-primary-foreground" : "text-muted-foreground hover:text-foreground",
            )}
          >
            {active && (
              <span className="absolute inset-0 -z-10 rounded-full bg-gradient-brand shadow-soft" />
            )}
            {it.label}
          </button>
        );
      })}
    </div>
  );
}