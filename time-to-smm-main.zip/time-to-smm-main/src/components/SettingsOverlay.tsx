import { useEffect, useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useTheme } from "@/lib/theme";
import {
  Sun,
  Moon,
  X,
  User as UserIcon,
  KeyRound,
  Sliders,
  Palette,
  Users as UsersIcon,
  Plus,
  Trash2,
  Pencil,
  ShieldAlert,
  UserX,
  Sparkles,
  Copy,
  RotateCcw,
  Save,
  Check,
} from "lucide-react";
import { useAuth, type AppUser } from "@/lib/auth";
import {
  useSettings,
  useSettingMutations,
  useUsers,
  useUserMutations,
} from "@/lib/data";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/components/ui/cinema-toast";
import { ColorPicker } from "./ColorPicker";
import { AVATAR_COLORS } from "@/lib/colors";
import { FullscreenConfirm } from "@/components/ui/fullscreen-confirm";
import { BrandLogo } from "./BrandLogo";

type TabKey = "profile" | "password" | "catalogs" | "appearance" | "users";

interface Props {
  open: boolean;
  onClose: () => void;
  /** Если true — таб «Пользователи» доступен (только для admin) */
  initialTab?: TabKey;
}

export function SettingsOverlay({ open, onClose, initialTab = "profile" }: Props) {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [tab, setTab] = useState<TabKey>(initialTab);

  useEffect(() => {
    if (open) setTab(initialTab);
  }, [open, initialTab]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const tabs: { key: TabKey; label: string; icon: React.ComponentType<{ className?: string }>; adminOnly?: boolean }[] = [
    { key: "profile", label: "Профиль", icon: UserIcon },
    { key: "password", label: "Пароль", icon: KeyRound },
    { key: "catalogs", label: "Площадки и форматы", icon: Sliders },
    { key: "appearance", label: "Внешний вид", icon: Palette },
    { key: "users", label: "Пользователи", icon: UsersIcon, adminOnly: true },
  ];

  const visibleTabs = tabs.filter((t) => !t.adminOnly || isAdmin);

  return (
    <div className="fixed inset-0 z-[80] flex flex-col bg-background animate-fade-in">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-border px-6 py-4 lg:px-10">
        <div className="flex items-center gap-6">
          <BrandLogo size={20} />
          <span className="hidden text-[10px] font-semibold uppercase tracking-[0.3em] text-muted-foreground md:inline">
            Настройки
          </span>
        </div>
        <button
          onClick={onClose}
          className="grid h-11 w-11 place-items-center rounded-2xl text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          aria-label="Закрыть"
        >
          <X className="h-5 w-5" />
        </button>
      </header>

      {/* Body: tabs sidebar + content */}
      <div className="flex min-h-0 flex-1 overflow-hidden">
        <nav className="hidden w-64 shrink-0 border-r border-border bg-card/40 p-3 md:block">
          <div className="space-y-1">
            {visibleTabs.map((t) => {
              const Icon = t.icon;
              const active = tab === t.key;
              return (
                <button
                  key={t.key}
                  onClick={() => setTab(t.key)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm transition-all duration-300 ease-soft",
                    active
                      ? "bg-accent text-accent-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-accent/60 hover:text-foreground",
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span className="flex-1">{t.label}</span>
                  {active && <Check className="h-3.5 w-3.5 text-primary" />}
                </button>
              );
            })}
          </div>
        </nav>

        {/* Mobile tab switcher */}
        <div className="absolute inset-x-0 top-[68px] z-10 flex gap-1 overflow-x-auto border-b border-border bg-background px-3 py-2 md:hidden">
          {visibleTabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "shrink-0 rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                tab === t.key ? "bg-accent text-accent-foreground" : "text-muted-foreground",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        <main className="min-h-0 flex-1 overflow-y-auto scroll-thin px-6 py-8 pt-20 md:px-10 md:pt-10">
          <div key={tab} className="mx-auto max-w-3xl animate-fade-in">
            {tab === "profile" && <ProfileTab />}
            {tab === "password" && <PasswordTab />}
            {tab === "catalogs" && <CatalogsTab />}
            {tab === "appearance" && <AppearanceTab />}
            {tab === "users" && isAdmin && <UsersTab />}
          </div>
        </main>
      </div>
    </div>
  );
}

/* =================== Профиль =================== */
function ProfileTab() {
  const { user, refresh } = useAuth();
  const { update } = useUserMutations();
  const [fullName, setFullName] = useState(user?.full_name ?? "");
  const [color, setColor] = useState(user?.avatar_color ?? AVATAR_COLORS[0]);
  const [saving, setSaving] = useState(false);

  if (!user) return null;

  async function save() {
    if (!user) return;
    if (!fullName.trim()) {
      toast.error("Имя не может быть пустым");
      return;
    }
    setSaving(true);
    try {
      const changes: string[] = [];
      if (fullName.trim() !== user.full_name) changes.push("ФИО");
      if (color !== user.avatar_color) changes.push("цвет аватара");
      await update.mutateAsync({ id: user.id, full_name: fullName.trim(), avatar_color: color });
      await refresh();
      toast.success("Профиль обновлён", {
        description: changes.length ? `Изменено: ${changes.join(", ")}` : "Изменения сохранены",
      });
    } catch (e: any) {
      toast.error("Не удалось сохранить", { description: e?.message });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-8">
      <SectionHeading
        title="Профиль"
        description="Основные данные вашей учётной записи"
      />
      <div className="flex items-center gap-5 rounded-3xl border border-border bg-card p-5">
        <div
          className="grid h-20 w-20 place-items-center rounded-3xl text-2xl font-semibold text-white shadow-soft"
          style={{ background: `linear-gradient(135deg, ${color}, ${color}cc)` }}
        >
          {user.full_name.split(" ").slice(0, 2).map((p) => p[0]).join("")}
        </div>
        <div>
          <div className="text-lg font-display font-semibold">{user.full_name}</div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">
            {user.role === "admin" ? "Администратор" : "Сотрудник"}
          </div>
        </div>
      </div>

      <Field label="Полное имя">
        <Input
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          maxLength={120}
          className="h-12 rounded-xl"
        />
      </Field>

      <Field label="Цвет аватара">
        <ColorPicker value={color} onChange={setColor} />
      </Field>

      <div className="flex justify-end">
        <Button size="lg" onClick={save} disabled={saving}>
          <Save className="h-4 w-4" /> {saving ? "Сохраняем…" : "Сохранить"}
        </Button>
      </div>
    </div>
  );
}

/* =================== Пароль =================== */
function PasswordTab() {
  const { user, refresh } = useAuth();
  const { update } = useUserMutations();
  const [currentPwd, setCurrentPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [repeatPwd, setRepeatPwd] = useState("");
  const [saving, setSaving] = useState(false);

  if (!user) return null;

  async function save() {
    if (!user) return;
    if (currentPwd !== user.password) {
      toast.error("Текущий пароль неверный");
      return;
    }
    if (newPwd.length < 4) {
      toast.error("Новый пароль слишком короткий", { description: "Минимум 4 символа" });
      return;
    }
    if (newPwd !== repeatPwd) {
      toast.error("Пароли не совпадают");
      return;
    }
    if (newPwd === currentPwd) {
      toast.warning("Новый пароль совпадает с текущим");
      return;
    }
    setSaving(true);
    try {
      await update.mutateAsync({ id: user.id, password: newPwd });
      await refresh();
      toast.success("Пароль изменён", { description: "Используйте новый пароль при следующем входе" });
      setCurrentPwd("");
      setNewPwd("");
      setRepeatPwd("");
    } catch (e: any) {
      toast.error("Не удалось обновить пароль", { description: e?.message });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-8">
      <SectionHeading
        title="Смена пароля"
        description="Введите текущий пароль и задайте новый"
      />
      <Field label="Текущий пароль">
        <Input
          type="password"
          value={currentPwd}
          onChange={(e) => setCurrentPwd(e.target.value)}
          className="h-12 rounded-xl"
          autoComplete="current-password"
        />
      </Field>
      <Field label="Новый пароль">
        <Input
          type="password"
          value={newPwd}
          onChange={(e) => setNewPwd(e.target.value)}
          className="h-12 rounded-xl"
          autoComplete="new-password"
        />
      </Field>
      <Field label="Повторите новый пароль">
        <Input
          type="password"
          value={repeatPwd}
          onChange={(e) => setRepeatPwd(e.target.value)}
          className="h-12 rounded-xl"
          autoComplete="new-password"
        />
      </Field>
      <div className="flex justify-end">
        <Button size="lg" onClick={save} disabled={saving || !currentPwd || !newPwd || !repeatPwd}>
          <KeyRound className="h-4 w-4" /> {saving ? "Сохраняем…" : "Изменить пароль"}
        </Button>
      </div>
    </div>
  );
}

/* =================== Площадки и форматы =================== */
function CatalogsTab() {
  const { data: settings = [] } = useSettings();
  const { create, remove } = useSettingMutations();
  const [newSource, setNewSource] = useState("");
  const [newType, setNewType] = useState("");

  const sources = settings.filter((s) => s.category === "source");
  const types = settings.filter((s) => s.category === "post_type");

  return (
    <div className="space-y-8">
      <SectionHeading
        title="Площадки и форматы"
        description="Справочники для удобства при создании постов"
      />
      <div className="grid gap-5 md:grid-cols-2">
        <CatalogList
          title="Площадки"
          items={sources}
          value={newSource}
          onValue={setNewSource}
          onAdd={async () => {
            const v = newSource.trim();
            if (!v) return;
            await create.mutateAsync({ category: "source", value: v, position: sources.length + 1 });
            setNewSource("");
            toast.success("Площадка добавлена", { description: `«${v}»` });
          }}
          onRemove={async (id, value) => {
            await remove.mutateAsync(id);
            toast.success("Площадка удалена", { description: `«${value}»` });
          }}
        />
        <CatalogList
          title="Форматы"
          items={types}
          value={newType}
          onValue={setNewType}
          onAdd={async () => {
            const v = newType.trim();
            if (!v) return;
            await create.mutateAsync({ category: "post_type", value: v, position: types.length + 1 });
            setNewType("");
            toast.success("Формат добавлен", { description: `«${v}»` });
          }}
          onRemove={async (id, value) => {
            await remove.mutateAsync(id);
            toast.success("Формат удалён", { description: `«${value}»` });
          }}
        />
      </div>
    </div>
  );
}

function CatalogList({
  title,
  items,
  value,
  onValue,
  onAdd,
  onRemove,
}: {
  title: string;
  items: { id: string; value: string }[];
  value: string;
  onValue: (v: string) => void;
  onAdd: () => void;
  onRemove: (id: string, value: string) => void;
}) {
  return (
    <section className="rounded-3xl border border-border bg-card p-5">
      <h4 className="mb-4 font-display text-base font-semibold">{title}</h4>
      <div className="mb-4 flex gap-2">
        <Input
          value={value}
          onChange={(e) => onValue(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), onAdd())}
          placeholder="Добавить…"
          className="h-11 rounded-xl"
        />
        <Button onClick={onAdd}>
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="max-h-[320px] space-y-1 overflow-y-auto scroll-thin">
        {items.map((s) => (
          <div
            key={s.id}
            className="group flex items-center justify-between rounded-xl px-3 py-2 transition-colors hover:bg-accent"
          >
            <span className="text-sm">{s.value}</span>
            <button
              onClick={() => onRemove(s.id, s.value)}
              className="text-muted-foreground opacity-0 transition-all hover:text-destructive group-hover:opacity-100"
              aria-label="Удалить"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
        {items.length === 0 && (
          <div className="rounded-xl border border-dashed border-border p-6 text-center text-xs text-muted-foreground">
            Список пуст
          </div>
        )}
      </div>
    </section>
  );
}

/* =================== Внешний вид =================== */
function AppearanceTab() {
  const { theme, setTheme } = useTheme();
  return (
    <div className="space-y-8">
      <SectionHeading title="Внешний вид" description="Тема оформления интерфейса" />
      <div className="grid grid-cols-2 gap-4">
        <ThemeCard
          active={theme === "light"}
          onClick={() => {
            setTheme("light");
            toast.success("Тема изменена", { description: "Светлая" });
          }}
          icon={<Sun className="h-5 w-5" />}
          label="Светлая"
        />
        <ThemeCard
          active={theme === "dark"}
          onClick={() => {
            setTheme("dark");
            toast.success("Тема изменена", { description: "Тёмная" });
          }}
          icon={<Moon className="h-5 w-5" />}
          label="Тёмная"
        />
      </div>
    </div>
  );
}

function ThemeCard({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex flex-col items-start gap-3 rounded-3xl border p-6 text-left transition-all duration-300",
        active ? "border-primary/50 bg-accent/30 shadow-soft" : "border-border bg-card hover:bg-accent/40",
      )}
    >
      <div
        className={cn(
          "grid h-11 w-11 place-items-center rounded-2xl",
          active ? "bg-gradient-brand text-primary-foreground" : "bg-muted text-muted-foreground",
        )}
      >
        {icon}
      </div>
      <div className="font-display text-lg font-semibold">{label}</div>
      <div
        className={cn(
          "ml-auto grid h-5 w-5 place-items-center rounded-full border-2 transition-all",
          active ? "border-primary bg-primary" : "border-border",
        )}
      >
        {active && <div className="h-1.5 w-1.5 rounded-full bg-white" />}
      </div>
    </button>
  );
}

/* =================== Пользователи =================== */
function UsersTab() {
  const { user: me } = useAuth();
  const { data: users = [] } = useUsers();
  const { create, update, remove } = useUserMutations();
  const [editing, setEditing] = useState<AppUser | null>(null);
  const [creating, setCreating] = useState(false);
  const [confirmDel, setConfirmDel] = useState<AppUser | null>(null);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <SectionHeading
          title="Сотрудники"
          description="Добавляйте, редактируйте, блокируйте и увольняйте"
        />
        <Button size="lg" onClick={() => setCreating(true)}>
          <Plus className="h-4 w-4" /> Добавить
        </Button>
      </div>

      <div className="space-y-2">
        {users.map((u) => {
          const fired = u.fired_at && new Date(u.fired_at).getTime() + 3 * 86400000 < Date.now();
          const inGrace = u.fired_at && !fired;
          const blocked = u.blocked_until && new Date(u.blocked_until) > new Date();
          return (
            <div
              key={u.id}
              className="flex items-center gap-3 rounded-2xl border border-border bg-card p-4 transition-shadow hover:shadow-soft"
            >
              <div
                className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-sm font-semibold text-white shadow-soft"
                style={{ background: `linear-gradient(135deg, ${u.avatar_color}, ${u.avatar_color}cc)` }}
              >
                {u.full_name.split(" ").slice(0, 2).map((p) => p[0]).join("")}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2 text-sm font-medium">
                  <span className="truncate">{u.full_name}</span>
                  {u.role === "admin" && (
                    <span className="rounded-md bg-primary/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-primary">
                      admin
                    </span>
                  )}
                  {fired && (
                    <span className="inline-flex items-center gap-1 rounded-md bg-destructive/10 px-1.5 py-0.5 text-[10px] text-destructive">
                      <UserX className="h-3 w-3" />
                      уволен
                    </span>
                  )}
                  {inGrace && (
                    <span className="inline-flex items-center gap-1 rounded-md bg-warning/10 px-1.5 py-0.5 text-[10px] text-warning">
                      <UserX className="h-3 w-3" />
                      увольнение
                    </span>
                  )}
                  {blocked && (
                    <span className="inline-flex items-center gap-1 rounded-md bg-warning/10 px-1.5 py-0.5 text-[10px] text-warning">
                      <ShieldAlert className="h-3 w-3" />
                      заблокирован
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-muted-foreground">
                  Пароль: <span className="font-mono">{u.password}</span>
                </div>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon-sm" onClick={() => setEditing(u)}>
                  <Pencil className="h-3.5 w-3.5" />
                </Button>
                {u.id !== me?.id && (
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    className="hover:bg-destructive/10 hover:text-destructive"
                    onClick={() => setConfirmDel(u)}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {(creating || editing) && (
        <UserEditOverlay
          user={editing}
          onClose={() => {
            setCreating(false);
            setEditing(null);
          }}
          onSubmit={async (data) => {
            if (editing) {
              await update.mutateAsync({ id: editing.id, ...data });
              toast.success("Сотрудник обновлён", { description: editing.full_name });
            } else {
              await create.mutateAsync(data);
              toast.success("Сотрудник добавлен", { description: data.full_name });
            }
            setCreating(false);
            setEditing(null);
          }}
        />
      )}

      <FullscreenConfirm
        open={!!confirmDel}
        onClose={() => setConfirmDel(null)}
        tone="danger"
        title={`Удалить ${confirmDel?.full_name ?? ""}?`}
        description="Это действие необратимо. Все связанные данные сотрудника останутся, но доступ будет закрыт."
        confirmLabel="Удалить"
        onConfirm={async () => {
          if (!confirmDel) return;
          await remove.mutateAsync(confirmDel.id);
          toast.success("Сотрудник удалён", { description: confirmDel.full_name });
          setConfirmDel(null);
        }}
      />
    </div>
  );
}

/* ----- редактор пользователя на оверлее ----- */
function UserEditOverlay({
  user,
  onClose,
  onSubmit,
}: {
  user: AppUser | null;
  onClose: () => void;
  onSubmit: (data: Partial<AppUser>) => Promise<void>;
}) {
  const [fullName, setFullName] = useState(user?.full_name ?? "");
  const [password, setPassword] = useState(user?.password ?? genPwd());
  const [role, setRole] = useState<"admin" | "user">((user?.role as any) ?? "user");
  const [color, setColor] = useState(user?.avatar_color ?? AVATAR_COLORS[0]);
  const [blockedUntil, setBlockedUntil] = useState<string>(user?.blocked_until?.slice(0, 10) ?? "");
  const [fired, setFired] = useState<boolean>(!!user?.fired_at);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && !saving && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose, saving]);

  async function handleSubmit() {
    if (!fullName.trim()) {
      toast.error("Имя сотрудника не может быть пустым");
      return;
    }
    if (!password || password.length < 4) {
      toast.error("Пароль слишком короткий", { description: "Минимум 4 символа" });
      return;
    }
    setSaving(true);
    try {
      await onSubmit({
        full_name: fullName.trim(),
        password,
        role,
        avatar_color: color,
        blocked_until: blockedUntil ? new Date(blockedUntil + "T23:59:59").toISOString() : null,
        fired_at: fired ? (user?.fired_at ?? new Date().toISOString()) : null,
      });
    } finally {
      setSaving(false);
    }
  }

  const initials = fullName
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("") || "?";

  return (
    <div className="fixed inset-0 z-[95] flex flex-col bg-background animate-fade-in">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(900px_circle_at_50%_-10%,hsl(var(--primary)/0.08),transparent_55%)]" />

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between border-b border-border bg-background/80 px-6 py-4 backdrop-blur lg:px-10">
        <div>
          <div className="text-[10px] font-semibold uppercase tracking-[0.3em] text-muted-foreground">
            {user ? "Редактирование" : "Новый сотрудник"}
          </div>
          <div className="mt-0.5 font-display text-lg font-semibold">
            {user ? user.full_name : "Заполните карточку"}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="lg" onClick={onClose} disabled={saving}>
            Отмена
          </Button>
          <Button size="lg" onClick={handleSubmit} disabled={saving}>
            <Save className="h-4 w-4" /> {saving ? "Сохраняем…" : user ? "Сохранить" : "Создать"}
          </Button>
          <button
            onClick={onClose}
            disabled={saving}
            aria-label="Закрыть"
            className="ml-2 grid h-11 w-11 place-items-center rounded-2xl text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Body */}
      <div className="relative z-10 flex-1 overflow-y-auto scroll-thin px-6 py-8 lg:px-10">
        <div className="mx-auto grid max-w-5xl gap-8 lg:grid-cols-[320px_1fr]">
          {/* Preview card */}
          <aside className="space-y-4">
            <div className="rounded-3xl border border-border bg-card p-6 text-center shadow-soft">
              <div
                className="mx-auto grid h-24 w-24 place-items-center rounded-3xl text-2xl font-semibold text-white shadow-soft transition-all duration-700"
                style={{ background: `linear-gradient(135deg, ${color}, ${color}cc)` }}
              >
                {initials}
              </div>
              <div className="mt-4 font-display text-lg font-semibold">{fullName || "Без имени"}</div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">
                {role === "admin" ? "Администратор" : "Сотрудник"}
              </div>

              <div className="mt-4 flex flex-wrap justify-center gap-1.5">
                {fired && (
                  <span className="inline-flex items-center gap-1 rounded-md bg-destructive/10 px-2 py-0.5 text-[10px] font-medium text-destructive">
                    <UserX className="h-3 w-3" /> уволен
                  </span>
                )}
                {blockedUntil && !fired && (
                  <span className="inline-flex items-center gap-1 rounded-md bg-warning/10 px-2 py-0.5 text-[10px] font-medium text-warning">
                    <ShieldAlert className="h-3 w-3" />
                    до {new Date(blockedUntil).toLocaleDateString("ru-RU")}
                  </span>
                )}
              </div>
            </div>

            <div className="rounded-2xl border border-border bg-card/60 p-4 text-xs text-muted-foreground">
              Подсказка: пароль можно сгенерировать или ввести вручную. Заблокированный сотрудник
              не сможет войти до указанной даты, увольнение — мгновенно.
            </div>
          </aside>

          {/* Form */}
          <section className="space-y-6">
            <div className="rounded-3xl border border-border bg-card p-6 shadow-soft">
              <h3 className="mb-4 font-display text-base font-semibold">Основное</h3>
              <div className="space-y-4">
                <Field label="ФИО">
                  <Input
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Иван Иванов"
                    className="h-12 rounded-xl"
                    maxLength={120}
                  />
                </Field>
                <Field label="Пароль">
                  <div className="flex gap-2">
                    <Input
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="h-12 rounded-xl font-mono"
                      placeholder="••••"
                    />
                    <Button type="button" variant="outline" onClick={() => setPassword(genPwd())} className="shrink-0">
                      <Sparkles className="h-4 w-4" />
                      <span className="hidden sm:inline">Создать</span>
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      className="shrink-0"
                      onClick={() => {
                        navigator.clipboard.writeText(password);
                        toast.success("Пароль скопирован", { description: "Передайте его сотруднику" });
                      }}
                      aria-label="Скопировать"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </Field>
              </div>
            </div>

            <div className="rounded-3xl border border-border bg-card p-6 shadow-soft">
              <h3 className="mb-4 font-display text-base font-semibold">Роль и доступ</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <Field label="Роль">
                  <div className="flex rounded-xl border border-border p-1">
                    {(["user", "admin"] as const).map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setRole(r)}
                        className={cn(
                          "flex-1 rounded-lg px-3 py-2.5 text-xs font-medium transition-all duration-500",
                          role === r ? "bg-gradient-brand text-primary-foreground shadow-soft" : "text-muted-foreground hover:text-foreground",
                        )}
                      >
                        {r === "admin" ? "Администратор" : "Сотрудник"}
                      </button>
                    ))}
                  </div>
                </Field>
                <Field label="Заблокировать до">
                  <div className="flex gap-2">
                    <Input
                      type="date"
                      value={blockedUntil}
                      onChange={(e) => setBlockedUntil(e.target.value)}
                      className="h-12 rounded-xl"
                    />
                    {blockedUntil && (
                      <Button type="button" variant="outline" size="icon" onClick={() => setBlockedUntil("")} aria-label="Сбросить">
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </Field>
              </div>
            </div>

            <div className="rounded-3xl border border-border bg-card p-6 shadow-soft">
              <h3 className="mb-4 font-display text-base font-semibold">Внешний вид</h3>
              <Field label="Цвет аватара">
                <ColorPicker value={color} onChange={setColor} />
              </Field>
            </div>

            {user && (
              <div
                className={cn(
                  "rounded-3xl border p-6 shadow-soft transition-colors duration-700",
                  fired ? "border-destructive/40 bg-destructive/5" : "border-border bg-card",
                )}
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="font-display text-base font-semibold">Увольнение</div>
                    <div className="mt-1 text-sm text-muted-foreground">
                      После увольнения у сотрудника есть 3 дня на восстановление, затем доступ закрывается окончательно.
                    </div>
                  </div>
                  {fired ? (
                    <Button type="button" variant="outline" onClick={() => setFired(false)}>
                      <RotateCcw className="h-4 w-4" /> Восстановить
                    </Button>
                  ) : (
                    <Button type="button" variant="destructive" onClick={() => setFired(true)}>
                      <UserX className="h-4 w-4" /> Уволить
                    </Button>
                  )}
                </div>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}

/* =================== shared =================== */
function SectionHeading({ title, description }: { title: string; description?: string }) {
  return (
    <div>
      <h2 className="font-display text-3xl font-extralight tracking-[-0.02em] md:text-4xl">{title}</h2>
      {description && <p className="mt-2 text-sm text-muted-foreground">{description}</p>}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function genPwd(len = 10) {
  const chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

// suppress unused warning for supabase import (retained in case of future use)
void supabase;
