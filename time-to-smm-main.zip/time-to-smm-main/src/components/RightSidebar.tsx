import { useMemo, useState } from "react";
import { useProjects, useProjectMutations, usePostMutations, usePosts } from "@/lib/data";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  FolderKanban,
  Plus,
  Pencil,
  Trash2,
  Filter,
  Settings as SettingsIcon,
  LogOut,
  Moon,
  Sun,
  Users as UsersIcon,
  Sparkles,
  ArrowRight,
} from "lucide-react";
import { useTheme } from "@/lib/theme";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ProjectDialog } from "./ProjectDialog";
import type { Project } from "@/lib/types";
import { toast } from "@/components/ui/cinema-toast";
import { FullscreenConfirm } from "@/components/ui/fullscreen-confirm";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Props {
  selectedProjectId: string | null;
  setSelectedProjectId: (id: string | null) => void;
  onOpenSettings: () => void;
  onOpenAdmin: () => void;
  onLogout?: () => void;
}

export function RightSidebar({
  selectedProjectId,
  setSelectedProjectId,
  onOpenSettings,
  onOpenAdmin,
  onLogout,
}: Props) {
  const { user, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const { data: projects = [] } = useProjects();
  const { data: posts = [] } = usePosts();
  const { remove } = useProjectMutations();
  const postMut = usePostMutations();

  const [editing, setEditing] = useState<Project | null>(null);
  const [creating, setCreating] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<Project | null>(null);
  const [deleteMode, setDeleteMode] = useState<"choose" | "delete-posts" | "move-posts">("choose");
  const [moveTargetId, setMoveTargetId] = useState<string>("");
  const [working, setWorking] = useState(false);

  const otherProjects = useMemo(
    () => projects.filter((p) => p.id !== confirmDelete?.id),
    [projects, confirmDelete],
  );
  const projectPostsCount = useMemo(
    () => (confirmDelete ? posts.filter((p) => p.project_id === confirmDelete.id).length : 0),
    [posts, confirmDelete],
  );

  const closeConfirm = () => {
    if (working) return;
    setConfirmDelete(null);
    setDeleteMode("choose");
    setMoveTargetId("");
  };

  const askDelete = (p: Project) => {
    if (projects.length <= 1) {
      toast.warning("Нельзя удалить единственный проект", {
        description: "Сначала создайте ещё один проект.",
      });
      return;
    }
    setConfirmDelete(p);
    setDeleteMode("choose");
    setMoveTargetId("");
  };

  const performDelete = async () => {
    if (!confirmDelete) return;
    setWorking(true);
    try {
      if (projectPostsCount > 0 && deleteMode === "delete-posts") {
        // Cascade: delete posts of this project first
        const ids = posts.filter((p) => p.project_id === confirmDelete.id).map((p) => p.id);
        await Promise.all(ids.map((id) => postMut.remove.mutateAsync(id)));
      } else if (projectPostsCount > 0 && deleteMode === "move-posts") {
        if (!moveTargetId) {
          toast.error("Выберите проект для переноса");
          setWorking(false);
          return;
        }
        const ids = posts.filter((p) => p.project_id === confirmDelete.id).map((p) => p.id);
        await Promise.all(
          ids.map((id) => postMut.update.mutateAsync({ id, project_id: moveTargetId })),
        );
      }
      await remove.mutateAsync(confirmDelete.id);
      if (selectedProjectId === confirmDelete.id) setSelectedProjectId(null);
      toast.success("Проект удалён", {
        description:
          projectPostsCount > 0
            ? deleteMode === "delete-posts"
              ? `Удалено постов: ${projectPostsCount}`
              : `Перенесено постов: ${projectPostsCount}`
            : undefined,
      });
      setConfirmDelete(null);
      setDeleteMode("choose");
      setMoveTargetId("");
    } catch (e: any) {
      toast.error("Не удалось удалить", { description: e?.message });
    } finally {
      setWorking(false);
    }
  };

  return (
    <aside className="hidden w-72 shrink-0 flex-col border-l border-border bg-sidebar/60 backdrop-blur-xl lg:flex">
      {/* Projects header */}
      <div className="flex items-center justify-between px-5 pt-5">
        <div className="flex items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-xl bg-accent text-accent-foreground">
            <FolderKanban className="h-4 w-4" />
          </div>
          <h3 className="font-display text-sm font-semibold tracking-tight">Проекты</h3>
        </div>
        <Button variant="ghost" size="icon-sm" onClick={() => setCreating(true)} aria-label="Добавить">
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      {/* "all" filter */}
      <div className="px-3 pt-3">
        <button
          onClick={() => setSelectedProjectId(null)}
          className={cn(
            "flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-sm transition-all duration-300 ease-soft",
            selectedProjectId === null
              ? "bg-accent text-accent-foreground shadow-sm"
              : "text-muted-foreground hover:bg-accent/60 hover:text-foreground",
          )}
        >
          <Filter className="h-4 w-4" />
          <span className="flex-1">Все проекты</span>
          {selectedProjectId === null && <Sparkles className="h-3.5 w-3.5 text-primary" />}
        </button>
      </div>

      {/* Projects list */}
      <div className="flex-1 overflow-y-auto scroll-thin px-3 pb-3 pt-1">
        <div className="space-y-1">
          {projects.length === 0 && (
            <div className="rounded-xl border border-dashed border-border p-4 text-center text-xs text-muted-foreground">
              Пока нет проектов.<br />
              Создайте первый, чтобы начать.
            </div>
          )}
          {projects.map((p, i) => {
            const active = selectedProjectId === p.id;
            return (
              <div
                key={p.id}
                className="group relative flex items-center"
                style={{ animation: `fade-in 400ms ${i * 40}ms both` }}
              >
                <button
                  onClick={() => setSelectedProjectId(active ? null : p.id)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm transition-all duration-300 ease-soft",
                    active
                      ? "bg-accent text-accent-foreground shadow-sm"
                      : "text-foreground/85 hover:bg-accent/60",
                  )}
                >
                  <span
                    className={cn(
                      "h-3 w-3 shrink-0 rounded-full transition-transform duration-300",
                      active && "scale-125 ring-2 ring-offset-2 ring-offset-background",
                    )}
                    style={{ background: p.color, boxShadow: `0 0 0 4px ${p.color}22` }}
                  />
                  <span className="flex-1 truncate font-medium">{p.name}</span>
                </button>
                <div className="absolute right-1 flex gap-0.5 opacity-0 transition-opacity duration-200 group-hover:opacity-100">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditing(p);
                    }}
                    className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground hover:bg-card hover:text-foreground"
                    aria-label="Редактировать"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      askDelete(p);
                    }}
                    className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/15 hover:text-destructive"
                    aria-label="Удалить"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Profile */}
      <Popover>
        <PopoverTrigger asChild>
          <button className="flex items-center gap-3 border-t border-border px-4 py-4 text-left transition-colors duration-300 hover:bg-accent/40">
            <div
              className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl text-sm font-semibold text-white shadow-soft"
              style={{
                background: `linear-gradient(135deg, ${user?.avatar_color}, ${user?.avatar_color}cc)`,
              }}
            >
              {user?.full_name
                .split(" ")
                .filter(Boolean)
                .slice(0, 2)
                .map((p) => p[0]?.toUpperCase())
                .join("")}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-medium">{user?.full_name}</div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">
                {user?.role === "admin" ? "Администратор" : "Сотрудник"}
              </div>
            </div>
            <SettingsIcon className="h-4 w-4 text-muted-foreground" />
          </button>
        </PopoverTrigger>
        <PopoverContent
          align="end"
          side="top"
          sideOffset={8}
          className="w-64 overflow-hidden rounded-2xl border-border p-1.5"
        >
          <MenuItem icon={<SettingsIcon className="h-4 w-4" />} onClick={onOpenSettings}>
            Настройки
          </MenuItem>
          <MenuItem
            icon={theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            onClick={toggle}
            right={
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                {theme === "dark" ? "Светлая" : "Тёмная"}
              </span>
            }
          >
            {theme === "dark" ? "Светлая тема" : "Тёмная тема"}
          </MenuItem>
          {user?.role === "admin" && (
            <MenuItem icon={<UsersIcon className="h-4 w-4" />} onClick={onOpenAdmin}>
              Управление пользователями
            </MenuItem>
          )}
          <div className="my-1 h-px bg-border" />
          <MenuItem
            icon={<LogOut className="h-4 w-4" />}
            onClick={() => {
              if (onLogout) onLogout();
              else logout();
            }}
            danger
          >
            Выйти
          </MenuItem>
        </PopoverContent>
      </Popover>

      {/* dialogs */}
      <ProjectDialog
        open={creating}
        onOpenChange={setCreating}
        ownerId={user?.id ?? null}
      />
      <ProjectDialog
        open={!!editing}
        onOpenChange={(o) => !o && setEditing(null)}
        ownerId={user?.id ?? null}
        project={editing ?? undefined}
      />
      <FullscreenConfirm
        open={!!confirmDelete}
        onClose={closeConfirm}
        tone="danger"
        title={`Удалить «${confirmDelete?.name ?? ""}»?`}
        description={
          projectPostsCount > 0
            ? `В проекте ${projectPostsCount} ${projectPostsCount === 1 ? "пост" : "постов"}. Что с ними делать?`
            : "Проект будет удалён. Постов в проекте нет."
        }
        confirmLabel={working ? "Удаляем…" : "Удалить проект"}
        cancelLabel="Отмена"
        loading={working || (projectPostsCount > 0 && deleteMode === "move-posts" && !moveTargetId)}
        onConfirm={performDelete}
      >
        {projectPostsCount > 0 && (
          <div className="space-y-3 text-left">
            <ChoiceCard
              active={deleteMode === "delete-posts"}
              onClick={() => setDeleteMode("delete-posts")}
              title="Удалить вместе с постами"
              description={`Все ${projectPostsCount} постов будут безвозвратно удалены.`}
              tone="danger"
              icon={<Trash2 className="h-5 w-5" />}
            />
            <ChoiceCard
              active={deleteMode === "move-posts"}
              onClick={() => setDeleteMode("move-posts")}
              title="Перенести посты в другой проект"
              description="Посты сохранятся, но будут привязаны к выбранному проекту."
              icon={<ArrowRight className="h-5 w-5" />}
            />
            {deleteMode === "move-posts" && (
              <div className="ml-2 animate-fade-in">
                <Select value={moveTargetId} onValueChange={setMoveTargetId}>
                  <SelectTrigger className="h-12 rounded-xl">
                    <SelectValue placeholder="Выберите проект…" />
                  </SelectTrigger>
                  <SelectContent>
                    {otherProjects.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        <span className="inline-flex items-center gap-2">
                          <span className="h-2.5 w-2.5 rounded-full" style={{ background: p.color }} />
                          {p.name}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        )}
      </FullscreenConfirm>
    </aside>
  );
}

function ChoiceCard({
  active,
  onClick,
  title,
  description,
  icon,
  tone,
}: {
  active: boolean;
  onClick: () => void;
  title: string;
  description: string;
  icon: React.ReactNode;
  tone?: "danger";
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex w-full items-start gap-3 rounded-2xl border p-4 text-left transition-all duration-300",
        active
          ? tone === "danger"
            ? "border-destructive/50 bg-destructive/5 shadow-soft"
            : "border-primary/50 bg-accent/40 shadow-soft"
          : "border-border bg-card/60 hover:border-primary/30 hover:bg-accent/30",
      )}
    >
      <div
        className={cn(
          "grid h-10 w-10 shrink-0 place-items-center rounded-xl",
          tone === "danger" ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary",
        )}
      >
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-sm font-semibold">{title}</div>
        <div className="mt-0.5 text-xs text-muted-foreground">{description}</div>
      </div>
      <div
        className={cn(
          "mt-1 grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 transition-all",
          active ? (tone === "danger" ? "border-destructive bg-destructive" : "border-primary bg-primary") : "border-border",
        )}
      >
        {active && <div className="h-1.5 w-1.5 rounded-full bg-white" />}
      </div>
    </button>
  );
}

function MenuItem({
  icon,
  children,
  right,
  onClick,
  danger,
}: {
  icon: React.ReactNode;
  children: React.ReactNode;
  right?: React.ReactNode;
  onClick?: () => void;
  danger?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm transition-colors duration-200",
        danger
          ? "text-destructive hover:bg-destructive/10"
          : "hover:bg-accent",
      )}
    >
      <span className="text-muted-foreground">{icon}</span>
      <span className="flex-1">{children}</span>
      {right}
    </button>
  );
}