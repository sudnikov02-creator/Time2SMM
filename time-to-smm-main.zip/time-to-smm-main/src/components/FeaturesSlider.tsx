import { useEffect, useState } from "react";
import {
  Sparkles,
  CalendarRange,
  Palette,
  Images,
  ShieldCheck,
  Bell,
  KeyRound,
  LayoutDashboard,
  Zap,
  Wand2,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Feature {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
}

const FEATURES: Feature[] = [
  { icon: Sparkles,        title: "AI-генерация постов",    description: "Один клик — и пост готов под площадку, формат и проект." },
  { icon: CalendarRange,   title: "Полноэкранный день",     description: "Кликни по дате — она раскроется на весь экран с расписанием." },
  { icon: Palette,         title: "Пастельные проекты",     description: "Спокойная палитра, мягкие акценты — глазам легче." },
  { icon: Images,          title: "Галерея в посте",        description: "Загружай несколько фото, увеличивай и удаляй в один клик." },
  { icon: ShieldCheck,     title: "Сотрудники",             description: "Роли, блокировки и увольнение — всё под контролем админа." },
  { icon: Bell,            title: "Морф-уведомления",       description: "Большой анонс плавно перетекает в полоску с таймером." },
  { icon: KeyRound,        title: "Смена пароля",           description: "Безопасно: текущий, новый, повтор." },
  { icon: LayoutDashboard, title: "Настройки на весь экран",description: "Профиль, пароль, справочники и оформление — в одном оверлее." },
  { icon: Zap,             title: "Быстрый старт",          description: "Лёгкий сплэш — заходишь и сразу за дело." },
  { icon: Wand2,           title: "Минимал-бренд",          description: "Тонкая типографика «time to smm.» — спокойно и премиально." },
];

const VISIBLE = 3;
const INTERVAL = 4500;

/** Три карточки функций сервиса в один ряд, авто-листание со сдвигом на одну. */
export function FeaturesSlider() {
  const [start, setStart] = useState(0);

  useEffect(() => {
    const t = window.setInterval(() => {
      setStart((s) => (s + 1) % FEATURES.length);
    }, INTERVAL);
    return () => window.clearInterval(t);
  }, []);

  const visible = Array.from({ length: VISIBLE }, (_, i) => FEATURES[(start + i) % FEATURES.length]);

  return (
    <div className="w-full">
      <div className="mb-3 flex items-center justify-between px-1">
        <span className="text-[10px] font-semibold uppercase tracking-[0.3em] text-muted-foreground">
          Возможности сервиса
        </span>
        <div className="flex gap-1.5">
          {FEATURES.map((_, i) => {
            const active = i >= start && i < start + VISIBLE;
            return (
              <button
                key={i}
                onClick={() => setStart(i % FEATURES.length)}
                aria-label={`К функции ${i + 1}`}
                className={cn(
                  "h-1.5 rounded-full transition-all duration-700 ease-soft",
                  active ? "w-5 bg-primary" : "w-1.5 bg-muted-foreground/30 hover:bg-muted-foreground/60",
                )}
              />
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {visible.map((f, i) => {
          const Icon = f.icon;
          return (
            <div
              key={`${start}-${i}-${f.title}`}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card/70 p-4 backdrop-blur-xl shadow-soft transition-all duration-700 ease-soft hover:-translate-y-1 hover:shadow-elevated animate-feature-pop"
              style={{ animationDelay: `${i * 90}ms` }}
            >
              <div className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full bg-primary/10 blur-2xl transition-opacity duration-700 group-hover:opacity-100 opacity-60" />
              <div className="relative z-10 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-brand text-primary-foreground shadow-soft">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="relative z-10 mt-4 font-display text-base font-semibold tracking-tight">{f.title}</h3>
              <p className="relative z-10 mt-1 line-clamp-2 text-xs text-muted-foreground">{f.description}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}