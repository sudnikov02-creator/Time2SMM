import { cn } from "@/lib/utils";

interface Props {
  className?: string;
  /** Размер шрифта логотипа в px (используется как базовый кегль) */
  size?: number;
  /** Совместимость со старым API — игнорируется в новом тексто-логотипе */
  withText?: boolean;
  textClassName?: string;
}

export function BrandLogo({ className, size = 28, textClassName }: Props) {
  // Тонкий редакционный текст-логотип: «time to smm.»
  return (
    <div className={cn("inline-flex items-baseline", className)}>
      <span
        className={cn(
          "font-display font-extralight lowercase tracking-[-0.02em] text-foreground",
          textClassName,
        )}
        style={{ fontSize: size, lineHeight: 1 }}
      >
        time to&nbsp;
      </span>
      <span
        className="font-display font-extralight lowercase tracking-[-0.02em] bg-gradient-brand bg-clip-text text-transparent"
        style={{ fontSize: size, lineHeight: 1 }}
      >
        smm
      </span>
      <span
        className="font-display font-extralight bg-gradient-brand bg-clip-text text-transparent"
        style={{ fontSize: size, lineHeight: 1 }}
      >
        .
      </span>
    </div>
  );
}