import { PROJECT_COLORS } from "@/lib/colors";
import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

interface Props {
  value: string;
  onChange: (color: string) => void;
  className?: string;
}

export function ColorPicker({ value, onChange, className }: Props) {
  return (
    <div className={cn("grid grid-cols-10 gap-2", className)}>
      {PROJECT_COLORS.map((c) => {
        const active = c.toLowerCase() === value.toLowerCase();
        return (
          <button
            key={c}
            type="button"
            onClick={() => onChange(c)}
            className={cn(
              "group relative grid aspect-square place-items-center rounded-xl transition-all duration-300 ease-soft hover:scale-110",
              active && "ring-2 ring-offset-2 ring-offset-background",
            )}
            style={{
              background: c,
              boxShadow: active ? `0 6px 18px -4px ${c}80` : `0 2px 6px -2px ${c}55`,
              ["--tw-ring-color" as any]: c,
            }}
            aria-label={`Цвет ${c}`}
          >
            {active && <Check className="h-4 w-4 text-white drop-shadow" />}
          </button>
        );
      })}
    </div>
  );
}