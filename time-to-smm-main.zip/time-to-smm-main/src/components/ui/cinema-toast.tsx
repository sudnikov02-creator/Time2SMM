import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { CheckCircle2, AlertTriangle, XCircle, Info, X } from "lucide-react";
import { cn } from "@/lib/utils";

export type ToastKind = "success" | "error" | "info" | "warning";

export interface ToastItem {
  id: string;
  kind: ToastKind;
  title: string;
  description?: string;
  /** ms for the bottom strip stage (default 3000) */
  stripDuration?: number;
}

interface Internal extends ToastItem {
  stage: "fullscreen" | "strip" | "leaving";
  createdAt: number;
}

interface Ctx {
  push: (t: Omit<ToastItem, "id">) => string;
  dismiss: (id: string) => void;
}

const ToastCtx = createContext<Ctx | null>(null);

const FULLSCREEN_MS = 1000;
const STRIP_MS_DEFAULT = 3000;
/** длительность плавного перетекания fullscreen → полоса */
const MORPH_MS = 1100;

let externalPush: ((t: Omit<ToastItem, "id">) => string) | null = null;

export function CinemaToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Internal[]>([]);
  const timers = useRef<Record<string, number[]>>({});

  const clearTimers = (id: string) => {
    (timers.current[id] ?? []).forEach((t) => window.clearTimeout(t));
    delete timers.current[id];
  };

  const dismiss = useCallback((id: string) => {
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, stage: "leaving" } : it)));
    clearTimers(id);
    window.setTimeout(() => {
      setItems((prev) => prev.filter((it) => it.id !== id));
    }, 500);
  }, []);

  const push = useCallback<Ctx["push"]>((t) => {
    const id = crypto.randomUUID();
    const item: Internal = {
      id,
      kind: t.kind,
      title: t.title,
      description: t.description,
      stripDuration: t.stripDuration ?? STRIP_MS_DEFAULT,
      stage: "fullscreen",
      createdAt: performance.now(),
    };
    // Только один тост за раз — заменяем предыдущий
    setItems([item]);

    const t1 = window.setTimeout(() => {
      setItems((prev) => prev.map((it) => (it.id === id ? { ...it, stage: "strip" } : it)));
      // Запускаем таймер закрытия только после завершения морфинга — чтобы прогресс совпал с реальным временем жизни полосы
      const t2 = window.setTimeout(() => dismiss(id), MORPH_MS + item.stripDuration);
      timers.current[id] = [...(timers.current[id] ?? []), t2];
    }, FULLSCREEN_MS);
    timers.current[id] = [t1];

    return id;
  }, [dismiss]);

  useEffect(() => {
    externalPush = push;
    return () => {
      externalPush = null;
    };
  }, [push]);

  const ctx = useMemo<Ctx>(() => ({ push, dismiss }), [push, dismiss]);

  // Только один тост одновременно (последовательная очередь визуально приоритетнее, чем стек)
  const current = items[items.length - 1];
  const isFullscreen = current?.stage === "fullscreen";
  const showBackdrop = isFullscreen;

  return (
    <ToastCtx.Provider value={ctx}>
      {children}

      {/* Backdrop без хард-цвета: только размытие + мягкое свечение по типу. Плавно тает за 1100мс. */}
      <div
        className={cn(
          "pointer-events-none fixed inset-0 z-[99] backdrop-blur-3xl transition-opacity ease-soft",
          showBackdrop ? "opacity-100" : "opacity-0",
        )}
        style={{
          transitionDuration: `${MORPH_MS}ms`,
          background: "hsl(var(--background) / 0.55)",
          pointerEvents: showBackdrop ? "auto" : "none",
        }}
        onClick={() => current && isFullscreen && dismiss(current.id)}
      >
        {current && (
          <div
            className="absolute inset-0 transition-opacity ease-soft"
            style={{
              background: kindGlow(current.kind),
              opacity: showBackdrop ? 1 : 0,
              transitionDuration: `${MORPH_MS}ms`,
            }}
          />
        )}
      </div>

      {/* Морфирующий контейнер — единый элемент, который меняет геометрию между стадиями */}
      {current && <MorphToast item={current} onClose={() => dismiss(current.id)} />}
    </ToastCtx.Provider>
  );
}

/* ========================================================================
 * Morphing toast — один элемент, плавно превращающийся из fullscreen в полосу
 * ====================================================================== */
function MorphToast({ item, onClose }: { item: Internal; onClose: () => void }) {
  const isFullscreen = item.stage === "fullscreen";
  const isLeaving = item.stage === "leaving";
  const stripMs = item.stripDuration ?? STRIP_MS_DEFAULT;

  // Бесшовный морф: одна и та же область экрана.
  // На fullscreen-фазе элемент центрирован, прозрачный (без квадратного card),
  // на strip-фазе — превращается в нижнюю полоску с фоном card и тонкой тенью.
  const easing = "cubic-bezier(0.22,1,0.36,1)";
  const transition =
    `top ${MORPH_MS}ms ${easing}, left ${MORPH_MS}ms ${easing}, right ${MORPH_MS}ms ${easing}, ` +
    `bottom ${MORPH_MS}ms ${easing}, width ${MORPH_MS}ms ${easing}, height ${MORPH_MS}ms ${easing}, ` +
    `border-radius ${MORPH_MS}ms ${easing}, transform ${MORPH_MS}ms ${easing}, ` +
    `opacity 600ms ease, background-color ${MORPH_MS}ms ${easing}, ` +
    `box-shadow ${MORPH_MS}ms ${easing}, border-color ${MORPH_MS}ms ${easing}, padding ${MORPH_MS}ms ${easing}`;

  const baseStyle: React.CSSProperties = {
    position: "fixed",
    zIndex: 100,
    transition,
    overflow: "hidden",
  };

  const fullscreenStyle: React.CSSProperties = {
    top: "50%",
    left: "50%",
    width: "min(720px, 92vw)",
    height: "auto",
    transform: "translate(-50%, -50%) scale(1)",
    borderRadius: 36,
    backgroundColor: "hsl(var(--card) / 0)",
    border: "1px solid hsl(var(--border) / 0)",
    boxShadow: "0 0 0 0 hsl(0 0% 0% / 0)",
  };

  const stripStyle: React.CSSProperties = {
    top: "auto",
    left: 16,
    right: 16,
    bottom: 16,
    width: "auto",
    transform: isLeaving ? "translateY(160%)" : "translateY(0)",
    borderRadius: 20,
    backgroundColor: "hsl(var(--card) / 1)",
    border: "1px solid hsl(var(--border) / 1)",
    boxShadow: "var(--shadow-lg)",
    opacity: isLeaving ? 0 : 1,
  };

  const style: React.CSSProperties = {
    ...baseStyle,
    ...(isFullscreen ? fullscreenStyle : stripStyle),
  };

  return (
    <div style={style} className="backdrop-blur-xl">
      <div
        className={cn(
          "flex items-center",
          isFullscreen ? "flex-col gap-6 px-8 py-10 text-center" : "flex-row gap-3 px-4 py-3 text-left",
        )}
        style={{ transition: `all ${MORPH_MS}ms ${easing}` }}
      >
        <div
          className={cn(
            "grid shrink-0 place-items-center",
            kindBadge(item.kind),
            isFullscreen ? "h-24 w-24 rounded-[2rem] shadow-elevated" : "h-9 w-9 rounded-xl",
          )}
          style={{ transition: `all ${MORPH_MS}ms ${easing}` }}
        >
          <KindIcon kind={item.kind} className={isFullscreen ? "h-12 w-12" : "h-4 w-4"} />
        </div>

        <div className="min-w-0 flex-1">
          <div
            className={cn(
              "font-display tracking-tight",
              isFullscreen ? "text-4xl font-extralight md:text-5xl" : "truncate text-sm font-semibold",
            )}
            style={{ transition: `font-size ${MORPH_MS}ms ${easing}, font-weight ${MORPH_MS}ms ${easing}` }}
          >
            {item.title}
          </div>
          {item.description && (
            <div
              className={cn(
                "text-muted-foreground",
                isFullscreen ? "mt-3 text-base md:text-lg" : "truncate text-xs",
              )}
              style={{ transition: `font-size ${MORPH_MS}ms ${easing}` }}
            >
              {item.description}
            </div>
          )}
        </div>

        {!isFullscreen && (
          <button
            onClick={onClose}
            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            aria-label="Закрыть"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Прогресс-индикатор: показывается ТОЛЬКО когда полоса полностью встала на место (после morph) */}
      <ProgressBar visible={!isFullscreen && !isLeaving} kind={item.kind} duration={stripMs} delay={MORPH_MS} />
    </div>
  );
}

/** Прогресс-индикатор закрытия — отдельный компонент, который перемонтируется при visibility,
 * чтобы анимация всегда стартовала с 100% и заканчивалась на 0%. */
function ProgressBar({ visible, kind, duration, delay }: { visible: boolean; kind: ToastKind; duration: number; delay: number }) {
  const [armed, setArmed] = useState(false);
  useEffect(() => {
    if (!visible) {
      setArmed(false);
      return;
    }
    // Дать полосе доехать на место, затем стартовать прогресс
    const t = window.setTimeout(() => setArmed(true), delay);
    return () => window.clearTimeout(t);
  }, [visible, delay]);

  return (
    <div
      className="pointer-events-none absolute inset-x-0 bottom-0 h-[3px] overflow-hidden"
      style={{ opacity: visible ? 1 : 0, transition: "opacity 300ms ease" }}
    >
      <div
        className={cn("h-full origin-left", kindBar(kind))}
        style={{
          transform: armed ? "scaleX(0)" : "scaleX(1)",
          transition: armed ? `transform ${duration}ms linear` : "none",
        }}
      />
    </div>
  );
}

function KindIcon({ kind, className }: { kind: ToastKind; className?: string }) {
  if (kind === "success") return <CheckCircle2 className={className} />;
  if (kind === "error") return <XCircle className={className} />;
  if (kind === "warning") return <AlertTriangle className={className} />;
  return <Info className={className} />;
}

function kindBadge(kind: ToastKind) {
  switch (kind) {
    case "success": return "bg-success text-success-foreground";
    case "error": return "bg-destructive text-destructive-foreground";
    case "warning": return "bg-warning text-warning-foreground";
    default: return "bg-primary text-primary-foreground";
  }
}
function kindBar(kind: ToastKind) {
  switch (kind) {
    case "success": return "bg-success";
    case "error": return "bg-destructive";
    case "warning": return "bg-warning";
    default: return "bg-primary";
  }
}
function kindGlow(kind: ToastKind) {
  const c =
    kind === "success" ? "152 60% 45%" :
    kind === "error" ? "0 72% 56%" :
    kind === "warning" ? "35 95% 55%" : "244 65% 58%";
  return `radial-gradient(900px circle at 50% 30%, hsl(${c} / 0.20), transparent 60%)`;
}

/* ---------- Imperative API (drop-in replacement for sonner.toast) ---------- */

function emit(kind: ToastKind, title: string, opts?: { description?: string }) {
  if (!externalPush) {
    // Provider not ready yet – queue on next tick
    setTimeout(() => externalPush?.({ kind, title, description: opts?.description }), 0);
    return "";
  }
  return externalPush({ kind, title, description: opts?.description });
}

type ToastFn = ((title: string, opts?: { description?: string }) => string) & {
  success: (title: string, opts?: { description?: string }) => string;
  error: (title: string, opts?: { description?: string }) => string;
  info: (title: string, opts?: { description?: string }) => string;
  warning: (title: string, opts?: { description?: string }) => string;
};

const baseToast = ((title: string, opts?: { description?: string }) => emit("info", title, opts)) as ToastFn;
baseToast.success = (title, opts) => emit("success", title, opts);
baseToast.error = (title, opts) => emit("error", title, opts);
baseToast.info = (title, opts) => emit("info", title, opts);
baseToast.warning = (title, opts) => emit("warning", title, opts);

export const toast = baseToast;

export function useCinemaToast() {
  const ctx = useContext(ToastCtx);
  if (!ctx) throw new Error("useCinemaToast must be used inside CinemaToastProvider");
  return ctx;
}