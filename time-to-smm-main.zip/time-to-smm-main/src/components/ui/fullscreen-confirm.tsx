import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { AlertTriangle, HelpCircle, X } from "lucide-react";

export type ConfirmTone = "default" | "danger" | "warning";

interface Props {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  tone?: ConfirmTone;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm?: () => void | Promise<void>;
  loading?: boolean;
  /** Custom body content rendered between description and footer */
  children?: React.ReactNode;
  /** Hide built-in confirm/cancel footer */
  hideFooter?: boolean;
}

export function FullscreenConfirm({
  open,
  onClose,
  title,
  description,
  tone = "default",
  confirmLabel = "Подтвердить",
  cancelLabel = "Отмена",
  onConfirm,
  loading,
  children,
  hideFooter,
}: Props) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const Icon = tone === "danger" ? AlertTriangle : tone === "warning" ? AlertTriangle : HelpCircle;

  return (
    <div className="fixed inset-0 z-[90] flex flex-col animate-iris-in">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-background/85 backdrop-blur-2xl"
        onClick={onClose}
      />
      <div
        className="pointer-events-none absolute inset-0"
        style={{ background: tone === "danger"
          ? "radial-gradient(900px circle at 50% 30%, hsl(0 72% 56% / 0.18), transparent 60%)"
          : tone === "warning"
          ? "radial-gradient(900px circle at 50% 30%, hsl(35 95% 55% / 0.18), transparent 60%)"
          : "radial-gradient(900px circle at 50% 30%, hsl(244 65% 58% / 0.18), transparent 60%)"
        }}
      />

      {/* Close */}
      <button
        onClick={onClose}
        className="absolute right-6 top-6 z-10 grid h-12 w-12 place-items-center rounded-2xl bg-card/70 text-muted-foreground shadow-soft backdrop-blur transition-colors hover:bg-card hover:text-foreground"
        aria-label="Закрыть"
      >
        <X className="h-5 w-5" />
      </button>

      <div className="relative z-10 mx-auto flex h-full w-full max-w-3xl flex-col items-center justify-center gap-8 px-6 py-12 text-center animate-zoom-fade">
        <div
          className={cn(
            "grid h-24 w-24 place-items-center rounded-[2rem] shadow-elevated",
            tone === "danger" && "bg-destructive text-destructive-foreground",
            tone === "warning" && "bg-warning text-warning-foreground",
            tone === "default" && "bg-gradient-brand text-primary-foreground",
          )}
        >
          <Icon className="h-12 w-12" />
        </div>

        <div className="space-y-3">
          <h2 className="font-display text-4xl font-bold tracking-tight md:text-5xl">{title}</h2>
          {description && (
            <p className="mx-auto max-w-xl text-base text-muted-foreground md:text-lg">{description}</p>
          )}
        </div>

        {children && <div className="w-full max-w-xl">{children}</div>}

        {!hideFooter && (
          <div className="flex flex-col-reverse gap-3 sm:flex-row">
            <Button variant="outline" size="xl" onClick={onClose} disabled={loading} className="min-w-[180px]">
              {cancelLabel}
            </Button>
            <Button
              size="xl"
              onClick={onConfirm}
              disabled={loading}
              className={cn(
                "min-w-[180px]",
                tone === "danger" && "bg-destructive text-destructive-foreground hover:bg-destructive/90",
                tone === "warning" && "bg-warning text-warning-foreground hover:bg-warning/90",
              )}
            >
              {confirmLabel}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}