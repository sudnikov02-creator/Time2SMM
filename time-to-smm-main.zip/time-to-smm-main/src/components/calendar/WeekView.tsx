import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { addDays, formatYMD, isSameDay, RU_WEEKDAYS_SHORT, startOfWeek } from "@/lib/dateUtils";
import type { Post, Project } from "@/lib/types";

interface Props {
  currentDate: Date;
  posts: Post[];
  projectsMap: Map<string, Project>;
  onPickDate: (d: Date) => void;
  onAddOnDate: (d: Date) => void;
  onPickPost: (p: Post) => void;
}

export function WeekView({ currentDate, posts, projectsMap, onPickDate, onAddOnDate, onPickPost }: Props) {
  const start = startOfWeek(currentDate);
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i));
  const today = new Date();

  const byDay = new Map<string, Post[]>();
  for (const p of posts) {
    const arr = byDay.get(p.scheduled_date) ?? [];
    arr.push(p);
    byDay.set(p.scheduled_date, arr);
  }

  return (
    <div className="grid h-full grid-cols-7 animate-fade-in">
      {days.map((d, i) => {
        const ymd = formatYMD(d);
        const list = (byDay.get(ymd) ?? []).slice().sort((a, b) =>
          (a.scheduled_time ?? "").localeCompare(b.scheduled_time ?? ""),
        );
        const isToday = isSameDay(d, today);
        return (
          <div
            key={ymd}
            className={cn(
              "group flex min-h-0 flex-col border-r border-b border-border bg-card/40 backdrop-blur-sm transition-colors duration-500",
              i === 6 && "border-r-0",
              isToday && "bg-accent/30",
            )}
            style={{ animation: `fade-in 400ms ${i * 50}ms both` }}
          >
            <div
              onClick={() => onPickDate(d)}
              className="flex cursor-pointer items-center justify-between border-b border-border px-3 py-2.5"
            >
              <div>
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
                  {RU_WEEKDAYS_SHORT[i]}
                </div>
                <div
                  className={cn(
                    "mt-0.5 inline-grid h-7 min-w-7 place-items-center rounded-full px-2 text-sm font-semibold",
                    isToday && "bg-gradient-brand text-primary-foreground shadow-soft",
                  )}
                >
                  {d.getDate()}
                </div>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onAddOnDate(d);
                }}
                className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground opacity-0 transition-all duration-300 group-hover:opacity-100 hover:bg-primary hover:text-primary-foreground"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="flex-1 space-y-1.5 overflow-y-auto scroll-thin p-2">
              {list.length === 0 && (
                <div className="grid h-full place-items-center text-center text-[11px] text-muted-foreground">
                  Постов нет
                </div>
              )}
              {list.map((p) => {
                const proj = p.project_id ? projectsMap.get(p.project_id) : null;
                const color = proj?.color ?? "#94a3b8";
                return (
                  <button
                    key={p.id}
                    onClick={() => onPickPost(p)}
                    className="block w-full rounded-xl border-l-[4px] px-3 py-2.5 text-left shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-soft"
                    style={{
                      borderLeftColor: color,
                      background: `${color}1f`,
                    }}
                  >
                    <div className="text-[11px] font-bold uppercase tracking-wider tabular-nums" style={{ color }}>
                      {p.scheduled_time?.slice(0, 5) ?? p.source}
                    </div>
                    <div className="mt-0.5 truncate text-sm font-semibold text-foreground">{p.title}</div>
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}