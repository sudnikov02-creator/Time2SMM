import { Plus, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatYMD, formatLongWeekday, isSameDay } from "@/lib/dateUtils";
import type { Post, Project } from "@/lib/types";
import { Button } from "@/components/ui/button";

interface Props {
  currentDate: Date;
  posts: Post[];
  projectsMap: Map<string, Project>;
  onAddOnDate: (d: Date) => void;
  onPickPost: (p: Post) => void;
}

export function DayView({ currentDate, posts, projectsMap, onAddOnDate, onPickPost }: Props) {
  const ymd = formatYMD(currentDate);
  const today = new Date();
  const isToday = isSameDay(currentDate, today);

  const list = posts
    .filter((p) => p.scheduled_date === ymd)
    .sort((a, b) => (a.scheduled_time ?? "").localeCompare(b.scheduled_time ?? ""));

  return (
    <div className="flex h-full w-full flex-col bg-card/40 backdrop-blur-sm animate-fade-in">
      <div className="flex items-center justify-between border-b border-border bg-background/60 px-6 py-5">
        <div>
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground">
            {isToday ? "Сегодня" : "День"}
          </div>
          <h2 className="mt-1 font-display text-2xl font-semibold capitalize tracking-tight">
            {formatLongWeekday(currentDate)}
          </h2>
        </div>
        <Button onClick={() => onAddOnDate(currentDate)} size="lg">
          <Plus className="h-4 w-4" /> Новый пост
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto scroll-thin px-6 py-6 md:px-12 lg:px-20">
        {list.length === 0 ? (
          <div className="grid h-full place-items-center">
            <div className="text-center">
              <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-accent text-accent-foreground">
                <Clock className="h-7 w-7" />
              </div>
              <h3 className="font-display text-lg font-semibold">На этот день нет постов</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Создайте первый пост — займёт меньше минуты.
              </p>
              <Button className="mt-5" onClick={() => onAddOnDate(currentDate)}>
                <Plus className="h-4 w-4" /> Добавить пост
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {list.map((p, i) => {
              const proj = p.project_id ? projectsMap.get(p.project_id) : null;
              const color = proj?.color ?? "#94a3b8";
              return (
                <button
                  key={p.id}
                  onClick={() => onPickPost(p)}
                  className={cn(
                    "group flex w-full items-start gap-4 rounded-2xl border border-border bg-background/60 p-4 text-left transition-all duration-300",
                    "hover:-translate-y-0.5 hover:border-primary/30 hover:shadow-soft",
                  )}
                  style={{ animation: `fade-in 400ms ${i * 60}ms both` }}
                >
                  <div
                    className="grid h-12 w-16 shrink-0 place-items-center rounded-xl text-sm font-semibold"
                    style={{ background: `${color}18`, color }}
                  >
                    {p.scheduled_time?.slice(0, 5) ?? "—"}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="truncate font-display text-base font-semibold">{p.title}</h3>
                      {proj && (
                        <span
                          className="rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider"
                          style={{ background: `${color}18`, color }}
                        >
                          {proj.name}
                        </span>
                      )}
                    </div>
                    <div className="mt-1 line-clamp-2 text-sm text-muted-foreground">
                      {p.content || "Без описания"}
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1.5 text-[11px]">
                      <Tag>{p.source}</Tag>
                      <Tag>{p.post_type}</Tag>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full border border-border bg-card/80 px-2 py-0.5 text-muted-foreground">
      {children}
    </span>
  );
}