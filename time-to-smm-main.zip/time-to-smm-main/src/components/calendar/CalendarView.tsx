import { useMemo } from "react";
import type { CalendarView } from "../AppHeader";
import type { Post, Project } from "@/lib/types";
import { MonthView } from "./MonthView";
import { WeekView } from "./WeekView";
import { DayView } from "./DayView";

interface Props {
  view: CalendarView;
  currentDate: Date;
  posts: Post[];
  projects: Project[];
  selectedProjectId: string | null;
  onPickDate: (d: Date) => void;
  onAddOnDate: (d: Date) => void;
  onPickPost: (p: Post) => void;
}

export function CalendarSurface(props: Props) {
  const filtered = useMemo(() => {
    if (!props.selectedProjectId) return props.posts;
    return props.posts.filter((p) => p.project_id === props.selectedProjectId);
  }, [props.posts, props.selectedProjectId]);

  const projectsMap = useMemo(() => {
    const m = new Map<string, Project>();
    for (const p of props.projects) m.set(p.id, p);
    return m;
  }, [props.projects]);

  const common = { posts: filtered, projectsMap, ...props };

  if (props.view === "month") return <MonthView {...common} />;
  if (props.view === "week") return <WeekView {...common} />;
  return <DayView {...common} />;
}