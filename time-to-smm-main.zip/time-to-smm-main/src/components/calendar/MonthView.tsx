import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  RU_WEEKDAYS_SHORT,
  formatYMD,
  isSameDay,
  monthGrid,
  parseYMD,
} from "@/lib/dateUtils";
import type { Post, Project } from "@/lib/types";

interface Props {
  currentDate: Date;
  posts: Post[];
  projectsMap: Map<string, Project>;
  onPickDate: (d: Date) => void;
  onAddOnDate: (d: Date) => void;
  onPickPost: (p: Post) => void;
}

export function MonthView({ currentDate, posts, projectsMap, onPickDate, onAddOnDate, onPickPost }: Props) {
  const grid = monthGrid(currentDate);
  const today = new Date();
  const monthIdx = currentDate.getMonth();

  // group posts by day
  const byDay = new Map<string, Post[]>();
  for (const p of posts) {
    const arr = byDay.get(p.scheduled_date) ?? [];
    arr.push(p);
    byDay.set(p.scheduled_date, arr);
  }

  return (
    <div className="flex h-full flex-col bg-card/40 backdrop-blur-sm animate-fade-in">
      <div className="grid grid-cols-7 border-b border-border bg-background/60">
        {RU_WEEKDAYS_SHORT.map((d, i) => (
          <div
            key={d}
            className={cn(
              "px-3 py-3 text-xs font-semibold uppercase tracking-widest text-muted-foreground",
              i >= 5 && "text-primary/70",
            )}
          >
            {d}
          </div>
        ))}
      </div>
      <div className="grid flex-1 grid-cols-7 grid-rows-6 overflow-hidden">
        {grid.map((d, idx) => {
          const ymd = formatYMD(d);
          const list = byDay.get(ymd) ?? [];
          const isToday = isSameDay(d, today);
          const inMonth = d.getMonth() === monthIdx;
          return (
            <div
              key={ymd + idx}
              onClick={() => onPickDate(d)}
              className={cn(
                "group relative flex min-h-0 flex-col gap-1.5 border-b border-r border-border p-2 transition-colors duration-300 cursor-pointer",
                "hover:bg-accent/40",
                !inMonth && "bg-muted/30 text-muted-foreground",
                idx % 7 === 6 && "border-r-0",
                idx >= 35 && "border-b-0",
              )}
            >
              <div className="flex items-center justify-between">
                <div
                  className={cn(
                    "grid h-7 w-7 place-items-center rounded-full text-xs font-semibold transition-all duration-300",
                    isToday
                      ? "bg-gradient-brand text-primary-foreground shadow-soft"
                      : inMonth
                      ? "text-foreground"
                      : "text-muted-foreground",
                  )}
                >
                  {d.getDate()}
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddOnDate(d);
                  }}
                  className={cn(
                    "grid h-6 w-6 place-items-center rounded-lg text-muted-foreground transition-all duration-300",
                    "opacity-0 group-hover:opacity-100 hover:bg-primary hover:text-primary-foreground",
                  )}
                  aria-label="Добавить пост"
                >
                  <Plus className="h-3.5 w-3.5" />
                </button>
              </div>
              <div className="flex-1 space-y-1.5 overflow-hidden">
                {list.slice(0, 3).map((p) => {
                  const proj = p.project_id ? projectsMap.get(p.project_id) : null;
                  const color = proj?.color ?? "#94a3b8";
                  return (
                    <button
                      key={p.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        onPickPost(p);
                      }}
                      className="block w-full truncate rounded-lg px-2 py-1.5 text-left text-[12px] font-semibold shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-soft"
                      style={{
                        background: `${color}26`,
                        color,
                        borderLeft: `3px solid ${color}`,
                      }}
                    >
                      {p.scheduled_time && (
                        <span className="mr-1 opacity-80 tabular-nums">{p.scheduled_time.slice(0, 5)}</span>
                      )}
                      {p.title}
                    </button>
                  );
                })}
                {list.length > 3 && (
                  <div
                    className="rounded-md px-2 py-0.5 text-[11px] font-semibold tracking-wide"
                    style={{ background: "hsl(var(--accent))", color: "hsl(var(--accent-foreground))" }}
                  >
                    +{list.length - 3} ещё
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// keep parseYMD reference so TS keeps the import
void parseYMD;