import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { ColorPicker } from "./ColorPicker";
import { useProjectMutations } from "@/lib/data";
import type { Project } from "@/lib/types";
import { PROJECT_COLORS } from "@/lib/colors";
import { toast } from "@/components/ui/cinema-toast";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  ownerId: string | null;
  project?: Project;
}

export function ProjectDialog({ open, onOpenChange, ownerId, project }: Props) {
  const [name, setName] = useState("");
  const [color, setColor] = useState<string>(PROJECT_COLORS[0]);
  const { create, update } = useProjectMutations();

  useEffect(() => {
    if (open) {
      setName(project?.name ?? "");
      setColor(project?.color ?? PROJECT_COLORS[0]);
    }
  }, [open, project]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    if (project) {
      const changes: string[] = [];
      if (project.name !== name.trim()) changes.push(`«${project.name}» → «${name.trim()}»`);
      if (project.color !== color) changes.push("цвет обновлён");
      await update.mutateAsync({ id: project.id, name: name.trim(), color });
      toast.success("Проект обновлён", {
        description: changes.length ? changes.join(" • ") : "Изменения сохранены",
      });
    } else {
      await create.mutateAsync({ name: name.trim(), color, owner_id: ownerId });
      toast.success("Проект создан", { description: `«${name.trim()}» добавлен в список` });
    }
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {project ? "Редактировать проект" : "Новый проект"}
          </DialogTitle>
          <DialogDescription>
            Назначьте имя и цвет — он будет использоваться в календаре.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-5 pt-2">
          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Название</Label>
            <Input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Например: Бренд X"
              className="h-11 rounded-xl"
              maxLength={60}
            />
          </div>
          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Цвет</Label>
            <ColorPicker value={color} onChange={setColor} />
          </div>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Отмена
            </Button>
            <Button type="submit" disabled={!name.trim() || create.isPending || update.isPending}>
              {project ? "Сохранить" : "Создать проект"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}