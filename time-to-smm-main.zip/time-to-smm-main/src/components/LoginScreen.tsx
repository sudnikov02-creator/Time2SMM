import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { AppUser } from "@/lib/auth";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BrandLogo } from "./BrandLogo";
import { Loader2, LockKeyhole, ChevronDown, ShieldAlert, UserX, Check } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { FeaturesSlider } from "./FeaturesSlider";

function format(dt: string) {
  return new Date(dt).toLocaleString("ru-RU", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function daysLeft(fromIso: string, totalDays: number) {
  const ms = new Date(fromIso).getTime() + totalDays * 86400000 - Date.now();
  return Math.max(0, Math.ceil(ms / 86400000));
}

export function LoginScreen() {
  const { setUser } = useAuth();
  const [users, setUsers] = useState<AppUser[]>([]);
  const [selected, setSelected] = useState<AppUser | null>(null);
  const [password, setPassword] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [usersLoading, setUsersLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("app_users")
        .select("*")
        .order("role", { ascending: true })
        .order("full_name", { ascending: true });
      setUsers((data ?? []) as AppUser[]);
      setUsersLoading(false);
    })();
  }, []);

  const status = useMemo(() => {
    if (!selected) return null;
    if (selected.fired_at) {
      const left = daysLeft(selected.fired_at, 3);
      if (left <= 0) return { kind: "fired" as const };
      return { kind: "fired-grace" as const, left };
    }
    if (selected.blocked_until && new Date(selected.blocked_until) > new Date()) {
      return { kind: "blocked" as const, until: selected.blocked_until };
    }
    return null;
  }, [selected]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!selected) return;
    setError(null);

    if (status?.kind === "fired") {
      setError("Сотрудник уволен. Доступ закрыт.");
      return;
    }
    if (status?.kind === "blocked") {
      setError(`Доступ заблокирован до ${format(status.until)}`);
      return;
    }

    if (password !== selected.password) {
      setError("Неверный пароль");
      return;
    }

    setLoading(true);
    // короткая имитация
    await new Promise((r) => setTimeout(r, 1200));
    setUser(selected);
    // приветствие покажет WelcomeSplash после входа
  }

  return (
    <div className="relative h-screen overflow-y-auto overflow-x-hidden bg-background scroll-thin">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(1100px_circle_at_50%_-10%,hsl(var(--primary)/0.12),transparent_55%)]" />
      <div className="pointer-events-none absolute bottom-0 right-0 h-[500px] w-[500px] rounded-full bg-primary-glow/10 blur-3xl" />

      <div className="relative z-10 mx-auto flex min-h-full w-full max-w-5xl flex-col gap-10 px-5 pb-12 pt-10 md:gap-14 md:pt-14">
        {/* Top: brand + 3 features */}
        <div className="flex flex-col items-center gap-8 animate-soft-rise">
          <BrandLogo size={26} />
          <FeaturesSlider />
        </div>

        {/* Center: login card */}
        <div className="mx-auto w-full max-w-md animate-soft-rise" style={{ animationDelay: "120ms" }}>
          <div className="mb-8 text-center">
            <h1 className="font-display text-4xl font-extralight tracking-[-0.03em] md:text-5xl">
              Рады видеть снова
            </h1>
            <p className="mt-3 text-sm text-muted-foreground">
              Выберите учётную запись и введите пароль
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Пользователь
              </Label>
              <Popover open={open} onOpenChange={setOpen}>
                <PopoverTrigger asChild>
                  <button
                    type="button"
                    disabled={usersLoading}
                    className={cn(
                      "group flex h-14 w-full items-center justify-between rounded-2xl border border-input bg-background px-4 text-left transition-all duration-300 ease-soft",
                      "hover:border-primary/50 hover:shadow-soft focus:outline-none focus:ring-2 focus:ring-ring",
                    )}
                  >
                    {selected ? (
                      <div className="flex items-center gap-3">
                        <Avatar user={selected} />
                        <div>
                          <div className="text-sm font-medium">{selected.full_name}</div>
                          <div className="text-[11px] uppercase tracking-wider text-muted-foreground">
                            {selected.role === "admin" ? "Администратор" : "Сотрудник"}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">
                        {usersLoading ? "Загрузка пользователей…" : "Выберите пользователя"}
                      </span>
                    )}
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 text-muted-foreground transition-transform duration-300",
                        open && "rotate-180",
                      )}
                    />
                  </button>
                </PopoverTrigger>
                <PopoverContent
                  className="w-[var(--radix-popover-trigger-width)] overflow-hidden rounded-2xl border-border p-1.5"
                  align="start"
                  sideOffset={6}
                >
                  <div className="max-h-[260px] overflow-y-auto scroll-thin">
                    {users.length === 0 && (
                      <div className="p-4 text-sm text-muted-foreground">Нет пользователей</div>
                    )}
                    {users.map((u) => {
                      const fired =
                        u.fired_at && daysLeft(u.fired_at, 3) <= 0 ? true : false;
                      const blocked =
                        u.blocked_until && new Date(u.blocked_until) > new Date();
                      return (
                        <button
                          key={u.id}
                          type="button"
                          onClick={() => {
                            setSelected(u);
                            setOpen(false);
                            setError(null);
                          }}
                          className={cn(
                            "group flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left transition-all duration-200 ease-soft",
                            "hover:bg-accent",
                            selected?.id === u.id && "bg-accent",
                          )}
                        >
                          <Avatar user={u} />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 text-sm font-medium">
                              <span className="truncate">{u.full_name}</span>
                              {u.role === "admin" && (
                                <span className="rounded-md bg-primary/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-primary">
                                  admin
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                              {fired && <UserX className="h-3 w-3" />}
                              {blocked && <ShieldAlert className="h-3 w-3" />}
                              <span>
                                {fired
                                  ? "Уволен"
                                  : blocked
                                  ? `Заблокирован до ${new Date(u.blocked_until!).toLocaleDateString("ru-RU")}`
                                  : u.role === "admin"
                                  ? "Администратор"
                                  : "Сотрудник"}
                              </span>
                            </div>
                          </div>
                          {selected?.id === u.id && <Check className="h-4 w-4 text-primary" />}
                        </button>
                      );
                    })}
                  </div>
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Пароль
              </Label>
              <div className="relative">
                <LockKeyhole className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError(null);
                  }}
                  placeholder="••••"
                  className="h-14 rounded-2xl pl-11 text-base"
                />
              </div>
            </div>

            {status?.kind === "blocked" && (
              <div className="flex items-start gap-3 rounded-2xl border border-warning/30 bg-warning/10 p-3 text-sm text-warning-foreground animate-fade-in">
                <ShieldAlert className="mt-0.5 h-4 w-4 text-warning" />
                <div>
                  <div className="font-medium">Учётная запись заблокирована</div>
                  <div className="text-xs text-muted-foreground">
                    Доступ откроется {format(status.until)}
                  </div>
                </div>
              </div>
            )}
            {status?.kind === "fired-grace" && (
              <div className="flex items-start gap-3 rounded-2xl border border-warning/30 bg-warning/10 p-3 text-sm animate-fade-in">
                <UserX className="mt-0.5 h-4 w-4 text-warning" />
                <div>
                  <div className="font-medium">Сотрудник уволен</div>
                  <div className="text-xs text-muted-foreground">
                    На восстановление осталось {status.left} дн.
                  </div>
                </div>
              </div>
            )}
            {status?.kind === "fired" && (
              <div className="flex items-start gap-3 rounded-2xl border border-destructive/30 bg-destructive/10 p-3 text-sm animate-fade-in">
                <UserX className="mt-0.5 h-4 w-4 text-destructive" />
                <div className="font-medium">Доступ закрыт. Сотрудник уволен.</div>
              </div>
            )}

            {error && (
              <div className="rounded-xl border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive animate-fade-in">
                {error}
              </div>
            )}

            <Button
              type="submit"
              size="xl"
              className="w-full"
              disabled={!selected || !password || loading || status?.kind === "fired" || status?.kind === "blocked"}
            >
              {loading ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Входим в систему…
                </>
              ) : (
                "Войти"
              )}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}

function Avatar({ user }: { user: AppUser }) {
  const initials = user.full_name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
  return (
    <div
      className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-xs font-semibold text-white shadow-soft"
      style={{ background: `linear-gradient(135deg, ${user.avatar_color}, ${user.avatar_color}cc)` }}
    >
      {initials || "U"}
    </div>
  );
}