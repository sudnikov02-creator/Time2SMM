import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { X, Sparkles, Upload, Trash2, Loader2, Save, ImageIcon, ZoomIn } from "lucide-react";
import type { Post, Project, AppSetting } from "@/lib/types";
import { formatYMD } from "@/lib/dateUtils";
import { usePostMutations, usePostImages, usePostImageMutations } from "@/lib/data";
import { supabase } from "@/integrations/supabase/client";
import { ImageZoomDialog } from "./ImageZoomDialog";
import { toast } from "@/components/ui/cinema-toast";
import { FullscreenConfirm } from "@/components/ui/fullscreen-confirm";

interface Props {
  open: boolean;
  onClose: () => void;
  date: Date | null;
  post: Post | null;
  projects: Project[];
  settings: AppSetting[];
  authorId: string | null;
  /** Встроенный режим: рендерится как часть FullscreenDayView, без aside */
  embedded?: boolean;
}

export function PostEditorPanel({ open, onClose, date, post, projects, settings, authorId, embedded }: Props) {
  const sources = settings.filter((s) => s.category === "source");
  const types = settings.filter((s) => s.category === "post_type");

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [time, setTime] = useState<string>("");
  const [source, setSource] = useState<string>(sources[0]?.value ?? "Telegram");
  const [postType, setPostType] = useState<string>(types[0]?.value ?? "Пост");
  const [projectId, setProjectId] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [zoom, setZoom] = useState<string | null>(null);
  const [confirmDel, setConfirmDel] = useState(false);

  const fileRef = useRef<HTMLInputElement>(null);
  const { create, update, remove } = usePostMutations();
  const { data: images = [] } = usePostImages(post?.id ?? null);
  const imgMut = usePostImageMutations(post?.id ?? null);

  useEffect(() => {
    if (!open) return;
    if (post) {
      setTitle(post.title);
      setContent(post.content);
      setTime(post.scheduled_time?.slice(0, 5) ?? "");
      setSource(post.source);
      setPostType(post.post_type);
      setProjectId(post.project_id);
    } else {
      setTitle("");
      setContent("");
      setTime("");
      setSource(sources[0]?.value ?? "Telegram");
      setPostType(types[0]?.value ?? "Пост");
      setProjectId(null);
    }
  }, [open, post]); // eslint-disable-line

  async function handleGenerate() {
    if (!title.trim()) {
      toast.error("Сначала введите заголовок");
      return;
    }
    setGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke("generate-post", {
        body: {
          title,
          source,
          postType,
          projectName: projects.find((p) => p.id === projectId)?.name,
        },
      });
      if (error) throw error;
      if ((data as any)?.error) throw new Error((data as any).error);
      const text = (data as any)?.content as string;
      if (text) {
        setContent(text);
        toast.success("Пост сгенерирован", { description: "Текст добавлен в редактор" });
      }
    } catch (e: any) {
      toast.error(e.message || "Не удалось сгенерировать");
    } finally {
      setGenerating(false);
    }
  }

  async function handleSave() {
    if (!title.trim() || !date) return;
    const payload = {
      title: title.trim(),
      content,
      scheduled_date: formatYMD(date),
      scheduled_time: time || null,
      source,
      post_type: postType,
      project_id: projectId,
      author_id: authorId,
    };
    if (post) {
      const changes: string[] = [];
      if (post.title !== payload.title) changes.push("заголовок");
      if ((post.content ?? "") !== (payload.content ?? "")) changes.push("текст");
      if ((post.scheduled_time ?? null) !== (payload.scheduled_time ?? null)) changes.push("время");
      if (post.source !== payload.source) changes.push("площадка");
      if (post.post_type !== payload.post_type) changes.push("формат");
      if ((post.project_id ?? null) !== (payload.project_id ?? null)) changes.push("проект");
      await update.mutateAsync({ id: post.id, ...payload });
      toast.success("Пост обновлён", {
        description: changes.length ? `Изменено: ${changes.join(", ")}` : `«${payload.title}»`,
      });
    } else {
      await create.mutateAsync(payload);
      toast.success("Пост создан", {
        description: `«${payload.title}» — ${payload.source} • ${payload.post_type}`,
      });
    }
    onClose();
  }

  async function handleDelete() {
    if (!post) return;
    setConfirmDel(true);
  }

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    let pid = post?.id;
    if (!pid) {
      if (!title.trim() || !date) {
        toast.error("Сначала введите заголовок и сохраните, чтобы прикрепить картинки");
        return;
      }
      const created = await create.mutateAsync({
        title: title.trim(),
        content,
        scheduled_date: formatYMD(date),
        scheduled_time: time || null,
        source,
        post_type: postType,
        project_id: projectId,
        author_id: authorId,
      });
      pid = created.id;
    }
    for (const f of Array.from(files)) {
      try {
        await imgMut.upload.mutateAsync(f);
      } catch {
        toast.error(`Не удалось загрузить ${f.name}`);
      }
    }
    toast.success("Картинки загружены", {
      description: `Добавлено: ${files.length} ${files.length === 1 ? "файл" : "файлов"}`,
    });
  }

  const Body = (
    <>
      {/* Title + Generate */}
      <div className="space-y-2">
        <Label className="text-xs uppercase tracking-wider text-muted-foreground">Заголовок</Label>
        <div className="flex gap-2">
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Идея поста…"
            maxLength={200}
            className="h-11 rounded-xl"
          />
          <Button
            type="button"
            variant="default"
            disabled={generating || !title.trim()}
            onClick={handleGenerate}
            className="shrink-0"
          >
            {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            <span className="hidden sm:inline">Сгенерировать</span>
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="space-y-2">
        <Label className="text-xs uppercase tracking-wider text-muted-foreground">Текст поста</Label>
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Напишите текст вручную или сгенерируйте через ✨"
          className="min-h-[180px] rounded-xl"
          maxLength={4000}
        />
      </div>

      {/* Source / Type */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">Площадка</Label>
          <Select value={source} onValueChange={setSource}>
            <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
            <SelectContent>
              {sources.map((s) => <SelectItem key={s.id} value={s.value}>{s.value}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">Формат</Label>
          <Select value={postType} onValueChange={setPostType}>
            <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
            <SelectContent>
              {types.map((s) => <SelectItem key={s.id} value={s.value}>{s.value}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Project / Time */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">Проект</Label>
          <Select value={projectId ?? "none"} onValueChange={(v) => setProjectId(v === "none" ? null : v)}>
            <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">Без проекта</SelectItem>
              {projects.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  <span className="inline-flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: p.color }} />
                    {p.name}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">Время</Label>
          <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="h-11 rounded-xl" />
        </div>
      </div>

      {/* Images */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">Картинки</Label>
          <Button
            variant="soft"
            size="pill"
            onClick={() => fileRef.current?.click()}
            disabled={imgMut.upload.isPending}
          >
            {imgMut.upload.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
            Загрузить
          </Button>
          <input
            ref={fileRef}
            type="file"
            hidden
            multiple
            accept="image/*"
            onChange={(e) => {
              handleFiles(e.target.files);
              e.target.value = "";
            }}
          />
        </div>
        {images.length === 0 ? (
          <div className="grid place-items-center rounded-2xl border border-dashed border-border p-6 text-center">
            <ImageIcon className="mb-2 h-6 w-6 text-muted-foreground" />
            <div className="text-xs text-muted-foreground">Картинок пока нет</div>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            {images.map((img) => (
              <div key={img.id} className="group relative aspect-square overflow-hidden rounded-xl border border-border bg-muted">
                <img src={img.public_url} alt="" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 flex items-end justify-between gap-1 bg-gradient-to-t from-black/60 to-transparent p-1.5 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                  <button onClick={() => setZoom(img.public_url)} className="grid h-7 w-7 place-items-center rounded-lg bg-card/90 text-foreground hover:bg-card" aria-label="Открыть">
                    <ZoomIn className="h-3.5 w-3.5" />
                  </button>
                  <button onClick={() => imgMut.remove.mutate(img)} className="grid h-7 w-7 place-items-center rounded-lg bg-destructive/90 text-destructive-foreground hover:bg-destructive" aria-label="Удалить">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );

  const Footer = (
    <div className="flex items-center justify-between gap-2 border-t border-border p-4">
      {post ? (
        <Button variant="ghost" onClick={handleDelete} className="text-destructive hover:bg-destructive/10">
          <Trash2 className="h-4 w-4" /> Удалить
        </Button>
      ) : <span />}
      <div className="flex gap-2">
        <Button variant="outline" onClick={onClose}>Отмена</Button>
        <Button onClick={handleSave} disabled={!title.trim() || create.isPending || update.isPending}>
          {(create.isPending || update.isPending) ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Сохранить
        </Button>
      </div>
    </div>
  );

  if (embedded) {
    if (!open) return null;
    return (
      <div className="flex h-full flex-col animate-fade-in">
        <div className="flex items-center justify-between border-b border-border/60 px-6 py-4 lg:px-10 lg:py-5">
          <div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
              {post ? "Редактирование" : "Новый пост"}
            </div>
            <h3 className="mt-0.5 font-display text-lg font-semibold">
              {date?.toLocaleDateString("ru-RU", { day: "numeric", month: "long" })}
            </h3>
          </div>
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="Закрыть редактор">
            <X className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex-1 space-y-5 overflow-y-auto scroll-thin px-6 py-6 lg:px-10">{Body}</div>
        {Footer}
        <ImageZoomDialog src={zoom} onOpenChange={(o) => !o && setZoom(null)} />
        <FullscreenConfirm
          open={confirmDel}
          onClose={() => setConfirmDel(false)}
          tone="danger"
          title="Удалить этот пост?"
          description={post ? `«${post.title}» будет удалён без возможности восстановления.` : ""}
          confirmLabel="Удалить"
          onConfirm={async () => {
            if (!post) return;
            await remove.mutateAsync(post.id);
            toast.success("Пост удалён", { description: `«${post.title}»` });
            setConfirmDel(false);
            onClose();
          }}
        />
      </div>
    );
  }

  return (
    <>
      <aside
        className={cn(
          "pointer-events-none fixed inset-y-0 right-0 z-50 flex w-[480px] max-w-full flex-col border-l border-border bg-card/95 shadow-elevated backdrop-blur-xl",
          "transition-[transform,opacity,filter] duration-[600ms] ease-soft lg:right-72",
          open ? "translate-x-0 opacity-100 pointer-events-auto blur-0" : "translate-x-[110%] opacity-0 blur-md",
        )}
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
              {post ? "Редактирование" : "Новый пост"}
            </div>
            <h3 className="mt-0.5 font-display text-lg font-semibold">
              {date?.toLocaleDateString("ru-RU", { day: "numeric", month: "long" })}
            </h3>
          </div>
          <Button variant="ghost" size="icon-sm" onClick={onClose}><X className="h-4 w-4" /></Button>
        </div>
        <div className="flex-1 space-y-5 overflow-y-auto scroll-thin px-5 py-5">{Body}</div>
        {Footer}
      </aside>

      <ImageZoomDialog src={zoom} onOpenChange={(o) => !o && setZoom(null)} />
      <FullscreenConfirm
        open={confirmDel}
        onClose={() => setConfirmDel(false)}
        tone="danger"
        title="Удалить этот пост?"
        description={post ? `«${post.title}» будет удалён без возможности восстановления.` : ""}
        confirmLabel="Удалить"
        onConfirm={async () => {
          if (!post) return;
          await remove.mutateAsync(post.id);
          toast.success("Пост удалён", { description: `«${post.title}»` });
          setConfirmDel(false);
          onClose();
        }}
      />
    </>
  );
}
