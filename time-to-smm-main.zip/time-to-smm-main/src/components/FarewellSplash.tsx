import { useEffect, useState } from "react";
import { BrandLogo } from "./BrandLogo";

interface Props {
  name: string;
  duration?: number;
  onDone: () => void;
}

function farewell() {
  const h = new Date().getHours();
  if (h < 5) return "Доброй ночи";
  if (h < 12) return "Хорошего дня";
  if (h < 18) return "Хорошего вечера";
  return "Спокойной ночи";
}

export function FarewellSplash({ name, duration = 2400, onDone }: Props) {
  const [progress, setProgress] = useState(2);

  useEffect(() => {
    const start = performance.now();
    let raf = 0;
    const tick = () => {
      const elapsed = performance.now() - start;
      const pct = Math.min(100, (elapsed / duration) * 100);
      setProgress(pct);
      if (elapsed >= duration) {
        setTimeout(onDone, 250);
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [duration, onDone]);

  const first = name.split(" ")[0] ?? name;
  const letters = first.split("");

  return (
    <div className="fixed inset-0 z-[120] grid place-items-center overflow-hidden bg-background">
      {/* мягкая радиальная подсветка + дрейфующий glow */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(900px_circle_at_50%_30%,hsl(var(--primary)/0.10),transparent_60%)]" />
      <div className="pointer-events-none absolute -bottom-40 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-primary-glow/15 blur-3xl animate-drift-y" />

      <div className="relative z-10 flex w-[min(960px,92vw)] flex-col items-center gap-12 text-center">
        <div className="animate-soft-rise">
          <BrandLogo size={26} />
        </div>

        <div className="space-y-5">
          <p
            className="font-display text-[11px] font-medium uppercase tracking-[0.4em] text-muted-foreground animate-soft-rise"
            style={{ animationDelay: "100ms" }}
          >
            До скорой встречи
          </p>
          <h1
            className="font-display font-extralight lowercase tracking-[-0.04em] text-foreground"
            style={{ fontSize: "clamp(3rem, 10vw, 9rem)", lineHeight: 0.95 }}
          >
            <span className="block animate-soft-rise" style={{ animationDelay: "180ms" }}>
              {farewell()},
            </span>
            <span aria-label={first} className="mt-2 inline-flex flex-wrap justify-center">
              {letters.map((ch, i) => (
                <span
                  key={i}
                  className="inline-block animate-letter-rise bg-gradient-brand bg-clip-text text-transparent"
                  style={{ animationDelay: `${300 + i * 55}ms`, whiteSpace: "pre" }}
                >
                  {ch}
                </span>
              ))}
              <span
                className="inline-block animate-letter-rise text-foreground"
                style={{ animationDelay: `${300 + letters.length * 55 + 100}ms` }}
              >
                .
              </span>
            </span>
          </h1>
        </div>

        <div
          className="w-full max-w-md animate-soft-rise"
          style={{ animationDelay: "500ms" }}
        >
          <div className="relative h-px w-full overflow-hidden bg-border/60">
            <div
              className="absolute inset-y-0 left-0 bg-gradient-brand transition-[width] duration-300 ease-soft"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="mt-4 text-[10px] font-medium uppercase tracking-[0.3em] text-muted-foreground">
            Сохраняем сессию…
          </div>
        </div>
      </div>
    </div>
  );
}