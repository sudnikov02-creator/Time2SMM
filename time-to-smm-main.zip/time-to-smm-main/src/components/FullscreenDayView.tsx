import { useMemo } from "react";
import { Plus, X, Clock, ArrowLeft } from "lucide-react";
import type { Post, Project } from "@/lib/types";
import { RU_MONTHS_GEN, RU_WEEKDAYS_LONG, dowMonday, isSameDay } from "@/lib/dateUtils";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { withAlpha } from "@/lib/colors";

interface Props {
  date: Date;
  posts: Post[];
  projectsMap: Map<string, Project>;
  selectedProject: Project | null;
  onClose: () => void;
  onAdd: () => void;
  onPick: (p: Post) => void;
  selectedPostId?: string | null;
  /** Если передан — показывается вместо списка постов (режим встроенного редактора) */
  rightSlot?: React.ReactNode;
}

export function FullscreenDayView({
  date,
  posts,
  projectsMap,
  selectedProject,
  onClose,
  onAdd,
  onPick,
  selectedPostId,
  rightSlot,
}: Props) {
  const isToday = isSameDay(date, new Date());
  const tint = selectedProject?.color;

  const sorted = useMemo(
    () => [...posts].sort((a, b) => (a.scheduled_time ?? "").localeCompare(b.scheduled_time ?? "")),
    [posts],
  );

  return (
    <div
      className="tint-surface relative flex h-full w-full overflow-hidden rounded-3xl border border-border shadow-soft animate-zoom-fade"
      style={tint ? ({ ["--tint" as any]: withAlpha(tint, 0.35) }) : undefined}
    >
      {/* Left: huge date */}
      <div className="relative flex w-[42%] min-w-[320px] flex-col justify-between border-r border-border/60 p-8 lg:p-12">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="Закрыть">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="text-[10px] font-semibold uppercase tracking-[0.3em] text-muted-foreground">
            {isToday ? "Сегодня" : "Запланировано"}
          </div>
        </div>

        <div className="space-y-2">
          <div className="font-display text-2xl font-semibold uppercase tracking-widest text-muted-foreground">
            {RU_WEEKDAYS_LONG[dowMonday(date)]}
          </div>
          <div className="mega-number bg-gradient-brand bg-clip-text text-transparent">
            {date.getDate()}
          </div>
          <div className="font-display text-3xl font-bold capitalize tracking-tight md:text-4xl">
            {RU_MONTHS_GEN[date.getMonth()]} {date.getFullYear()}
          </div>
          {selectedProject && (
            <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1.5 backdrop-blur">
              <span
                className="h-2.5 w-2.5 rounded-full"
                style={{ background: selectedProject.color }}
              />
              <span className="text-xs font-medium">{selectedProject.name}</span>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between gap-3">
          <div className="text-sm text-muted-foreground">
            {sorted.length === 0
              ? "Нет запланированных постов"
              : `${sorted.length} ${plural(sorted.length, "пост", "поста", "постов")}`}
          </div>
          <Button onClick={onAdd} size="lg">
            <Plus className="h-4 w-4" /> Добавить пост
          </Button>
        </div>
      </div>

      {/* Right: posts */}
      <div className="flex flex-1 flex-col">
        {rightSlot ? (
          <div className="h-full">{rightSlot}</div>
        ) : (
          <>
        <div className="flex items-center justify-between border-b border-border/60 px-6 py-4 lg:px-10 lg:py-5">
          <h3 className="font-display text-lg font-semibold tracking-tight">Расписание</h3>
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="Закрыть">
            <X className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex-1 overflow-y-auto scroll-thin px-6 py-6 lg:px-10">
          {sorted.length === 0 ? (
            <EmptyState onAdd={onAdd} />
          ) : (
            <div className="space-y-3">
              {sorted.map((p, i) => {
                const proj = p.project_id ? projectsMap.get(p.project_id) : null;
                const color = proj?.color ?? "#cbd5e1";
                const active = selectedPostId === p.id;
                return (
                  <button
                    key={p.id}
                    onClick={() => onPick(p)}
                    style={{
                      animation: `slide-stack 500ms cubic-bezier(0.22,1,0.36,1) ${i * 60}ms both`,
                    }}
                    className={cn(
                      "group flex w-full items-stretch gap-4 rounded-2xl border p-4 text-left transition-all duration-300 hover:-translate-y-0.5 hover:shadow-soft",
                      active
                        ? "border-primary/40 bg-card shadow-soft"
                        : "border-border bg-card/60 backdrop-blur",
                    )}
                  >
                    <div
                      className="grid w-20 shrink-0 place-items-center rounded-xl text-base font-bold"
                      style={{ background: withAlpha(color, 0.18), color: darkenColor(color) }}
                    >
                      {p.scheduled_time?.slice(0, 5) ?? "—"}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-display text-base font-semibold">{p.title}</div>
                      {p.content && (
                        <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{p.content}</p>
                      )}
                      <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                        <Badge>{p.source}</Badge>
                        <Badge>{p.post_type}</Badge>
                        {proj && (
                          <span
                            className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium"
                            style={{ background: withAlpha(color, 0.2), color: darkenColor(color) }}
                          >
                            <span
                              className="h-1.5 w-1.5 rounded-full"
                              style={{ background: color }}
                            />
                            {proj.name}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
          </>
        )}
      </div>
    </div>
  );
}

function EmptyState({ onAdd }: { onAdd: () => void }) {
  return (
    <div className="grid h-full place-items-center text-center">
      <div className="max-w-sm">
        <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-accent">
          <Clock className="h-7 w-7 text-accent-foreground" />
        </div>
        <h4 className="font-display text-xl font-semibold">Постов пока нет</h4>
        <p className="mt-1 text-sm text-muted-foreground">Создайте первый — он появится здесь.</p>
        <Button onClick={onAdd} size="lg" className="mt-5">
          <Plus className="h-4 w-4" /> Добавить пост
        </Button>
      </div>
    </div>
  );
}

function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
      {children}
    </span>
  );
}

function plural(n: number, one: string, few: string, many: string) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m100 >= 11 && m100 <= 14) return many;
  if (m10 === 1) return one;
  if (m10 >= 2 && m10 <= 4) return few;
  return many;
}

/** Make a pastel color readable on light surfaces by darkening it */
function darkenColor(hex: string) {
  const c = hex.replace("#", "");
  const r = parseInt(c.slice(0, 2), 16);
  const g = parseInt(c.slice(2, 4), 16);
  const b = parseInt(c.slice(4, 6), 16);
  const f = 0.45;
  const r2 = Math.round(r * f);
  const g2 = Math.round(g * f);
  const b2 = Math.round(b * f);
  return `rgb(${r2}, ${g2}, ${b2})`;
}