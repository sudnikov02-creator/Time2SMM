import { useEffect, useState } from "react";
import { BrandLogo } from "./BrandLogo";

interface Props {
  /** Минимальная длительность мс. По умолчанию 4–8 сек (на 2 сек быстрее, чем раньше). */
  minDuration?: number;
  label?: string;
  onDone: () => void;
}

export function SplashScreen({ minDuration, label = "Загружаем сервис", onDone }: Props) {
  const [progress, setProgress] = useState(2);
  const [duration] = useState(() => minDuration ?? 4000 + Math.floor(Math.random() * 4000));

  useEffect(() => {
    const start = performance.now();
    let raf = 0;
    const tick = () => {
      const elapsed = performance.now() - start;
      const pct = Math.min(99, (elapsed / duration) * 100);
      setProgress(pct);
      if (elapsed >= duration) {
        setProgress(100);
        setTimeout(onDone, 350);
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [duration, onDone]);

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-background">
      {/* мягкое свечение */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(700px_circle_at_50%_30%,hsl(var(--primary)/0.10),transparent_60%)]" />

      <div className="relative z-10 flex w-[min(520px,92vw)] flex-col items-center gap-12 animate-fade-in">
        <BrandLogo size={48} />

        <div className="w-full">
          <div className="relative h-px w-full overflow-hidden bg-border/60">
            <div
              className="absolute inset-y-0 left-0 bg-gradient-brand transition-[width] duration-300 ease-soft"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="mt-4 flex justify-between text-[10px] font-medium uppercase tracking-[0.3em] text-muted-foreground">
            <span>{label}</span>
            <span className="tabular-nums">{Math.floor(progress)}%</span>
          </div>
        </div>
      </div>
    </div>
  );
}