import { useEffect, useRef, useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Minus, Plus, RotateCcw } from "lucide-react";

interface Props {
  src: string | null;
  onOpenChange: (o: boolean) => void;
}

export function ImageZoomDialog({ src, onOpenChange }: Props) {
  const [scale, setScale] = useState(1);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const drag = useRef<{ x: number; y: number; sx: number; sy: number } | null>(null);

  useEffect(() => {
    if (src) {
      setScale(1);
      setPos({ x: 0, y: 0 });
    }
  }, [src]);

  function reset() {
    setScale(1);
    setPos({ x: 0, y: 0 });
  }

  async function download() {
    if (!src) return;
    try {
      const res = await fetch(src);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = src.split("/").pop() || "image";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch {
      window.open(src, "_blank");
    }
  }

  return (
    <Dialog open={!!src} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl overflow-hidden border-border bg-background/95 p-0">
        <div
          className="relative h-[80vh] w-full select-none overflow-hidden bg-[radial-gradient(circle_at_50%_30%,hsl(var(--primary)/0.08),transparent_60%)]"
          onWheel={(e) => {
            e.preventDefault();
            const delta = -Math.sign(e.deltaY) * 0.15;
            setScale((s) => Math.min(5, Math.max(0.5, s + delta)));
          }}
          onMouseDown={(e) => {
            drag.current = { x: e.clientX, y: e.clientY, sx: pos.x, sy: pos.y };
          }}
          onMouseMove={(e) => {
            if (!drag.current) return;
            setPos({
              x: drag.current.sx + (e.clientX - drag.current.x),
              y: drag.current.sy + (e.clientY - drag.current.y),
            });
          }}
          onMouseUp={() => (drag.current = null)}
          onMouseLeave={() => (drag.current = null)}
        >
          {src && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={src}
              alt="preview"
              draggable={false}
              className="absolute left-1/2 top-1/2 max-h-none max-w-none -translate-x-1/2 -translate-y-1/2 transition-transform duration-200"
              style={{
                transform: `translate(-50%, -50%) translate(${pos.x}px, ${pos.y}px) scale(${scale})`,
                cursor: drag.current ? "grabbing" : "grab",
              }}
            />
          )}
          <div className="pointer-events-none absolute inset-x-0 bottom-4 flex justify-center">
            <div className="pointer-events-auto flex items-center gap-1 rounded-full border border-border bg-card/80 p-1 backdrop-blur-xl shadow-elevated">
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={() => setScale((s) => Math.max(0.5, s - 0.25))}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <div className="w-12 text-center text-xs font-medium tabular-nums">
                {Math.round(scale * 100)}%
              </div>
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={() => setScale((s) => Math.min(5, s + 0.25))}
              >
                <Plus className="h-4 w-4" />
              </Button>
              <div className="mx-1 h-5 w-px bg-border" />
              <Button variant="ghost" size="icon-sm" onClick={reset}>
                <RotateCcw className="h-4 w-4" />
              </Button>
              <Button variant="default" size="pill" onClick={download}>
                <Download className="h-3.5 w-3.5" /> Скачать
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}